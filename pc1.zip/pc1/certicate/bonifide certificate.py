from tkinterweb import HtmlFrame
from tkinter import *
import pymysql
from pyscreenshot import *
from PIL import Image,ImageTk
import cv2

root = Tk() 
root.title("Bonifide Certificate")
root.resizable(False,False)
global Input_1
imagepath = StringVar()
# def insertrecord():
search_record = StringVar()
fname = StringVar()
db_config = {
    "host": "localhost",
    "user": "kavita",
    "password": "1981",
    "database": "school",
}
connector = pymysql.connect(**db_config)

def open_image():
    imageid = Entry_registernum_up.get()
    imagename='student'+"("+imageid+",)"+".jpg"
    
    #print(imagename)
        # Python program to explain cv2.imshow() method
        
    image = Image.open(imagename)
        #image.show()
    photo = ImageTk.PhotoImage(image)
    varun_label = Label(image=photo,height=50,width=50)
    varun_label.place(relx=0.58,y=110,relheight=0.2,relwidth=0.2)
       # photo
        
    # Reading an image in default mode
    image = cv2.imread(imagepath)

    # Window name in which image is displayed
    window_name = 'image'
    if window_name:
         cv2.waitKey(0)
    else: 
           print("no image")

def search_record():
    open_image()
    db_config = {
    "host": "localhost",
    "user": "kavita",
    "password": "1981",
    "database": "school",
}
    connector = pymysql.connect(**db_config)
    conn = connector.cursor()
    #connection = sqlite3.connect("school.db")
    #conn = connection.cursor()
    print("Connected")
    record_id = Entry_registernum_up.get()
    conn.execute("SELECT * FROM newregister3 where registernum = " + record_id)
    # messagebox.showinfo("Message","Database records selected")
    records = conn.fetchall()
    print("Fetched")
    for record in records:
        print("Inserting Records!!!!!!")
        Label_fname = Label(root,text=record[3] + " "+record[5] + " " +record[6],font=30,bg="white")
        Label_fname.place(x=150,y=250)
        Label_amistd=Label(root,text=record[19],font=30,bg="white")
        Label_amistd.place(x=350,y=450 )
        
global Input_fname
Input_fname=StringVar()
root.geometry("800x750+0+0")
root.resizable(False,False)
        
#Html Frame
frame = HtmlFrame(root) #create HTML rootr
frame.config()
#frame.load_file("file:///C:/Users/Yash/Desktop/13-06-2023/5062023/leavingcertificate1.html")
frame.load_file("D://installed software//pc1//pc1//certicate//bonfide1.html")
frame.pack(fill="both", expand=True) #attach the HtmlFrame widget to the parent window
Entry_registernum_up = Entry(root,font=5,bg="white",width=5)
Entry_registernum_up.place(x=230,y=200)
Entry_registernum_up.focus()
Entry_registernum_up.bind("<Return>",lambda event: search_record())

#Label_fname = Label(root,text=record[3] + " "+record[5] + " " +record[6],bg="white")
#Label_fname.place(x=50,y=50)

#Entry_registernum_up.bind('<Return>',lambda event:search_record())
# Entry_registernum_up.focus()
#root.bind('<Control-p>',lambda event: printer())
root.mainloop()