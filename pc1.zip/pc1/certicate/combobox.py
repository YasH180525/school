from cgitb import text
import tkinter as tk
from tkinter import Button, StringVar, ttk
import pymysql
from tkinter import *   #support the label and entry input
import tkinter.messagebox as mb
import tkinter.messagebox as mb   #support  the messagebox 
import tkinter.ttk as ttk   #support the treeview and ttk
from tkinter import messagebox #support  the messagebox 
import tkinter.messagebox as tkMessageBox
headlabelfont = ("Times New Roman", 15, 'bold')
labelfont = ('Helvetica', 14)
entryfont = ('Helvetica', 12)


db_config={
    "user":"kavita",
    "host":"localhost",
    "password":"1981",
    "database":"studstanddiv"
}

db_config_school = {
    "user": "kavita",
    "password" : "1981",
    "host" : "localhost",
    "database" : "school"
}

db_config_standard = {
    "user": "kavita",
    "password" : "1981",
    "host" : "localhost",
    "database" : "standard"
}

db_config_division = {
    "user": "kavita",
    "password" : "1981",
    "host" : "localhost",
    "database" : "division"
}
def reset_fields():
   global studstanddivid,registerid,standardid,divisionid,standardname,fullname,divisionname
   
   for i in ['studstanddivid','registerid','standardid','divisionid','standardname','fullname','divisionname']:
      exec(f"{i}.set('')")
   #pass
def reset_form():
   global tree
   tree.delete(*tree.get_children())
   reset_fields()
   #SEARCH.set(" ")

def display_records():
    global tree,tree1
    tree.delete(*tree.get_children())
    connection = pymysql.connect(**db_config)
    conn = connection.cursor()
    conn.execute("select * from studentstanddivtable")
    #cursor=conn.execute("select fullname,standardname,divisionname from newregister3,standardtable,divisiontable where studstanddivtable.registerid=newregister3.registerid and studstanddiv.standardid=dtandardtable.standardid and studstanddiv.divisionid=divisionid.divisiontable")
    #cursor=conn.execute("select fullname,standardname,divisionname from studstanddivtable where registerid=%s and standardid=%s and divisionid=%s",(studentfullname.get(),standardname.get(),divisionname.get()))
    data = conn.fetchall()
    for datas in data:
       tree1.insert('',END, values=datas[0]+" "+datas[1]+" "+datas[2])
#     tree.delete(*tree.get_children())
#     connection = pymysql.connect(**db_config)
#     #cursor=conn.execute("select fullname,standardname,divisionname from newregister3,standardtable,divisiontable where studstanddivtable.registerid=newregister3.registerid and studstanddiv.standardid=dtandardtable.standardid and studstanddiv.divisionid=divisionid.divisiontable")
#     #cursor=conn.execute("select fullname,standardname,divisionname from studstanddivtable where registerid=%s and standardid=%s and divisionid=%s",(studentfullname.get(),standardname.get(),divisionname.get()))
    
#     cursor=connection.cursor()
#     #cursor.execute('SELECT registernum, studentid,studentname,adharnumber,fathersname,surname,mothersname,mobileno,address,nationality,mothertongue,dharma,jat,potjat,Birthdate,birthplace,oldschool,Admidate,admistd,studyprogress,behaviour,Schoolleftdate,schoolleftreason,remark,Bankaccountno,Bankname,Bankbranch,Bankifsc,pustaknumber,lcyn,Leavingcertificateissuedate, taluka, jhila,rajya FROM newregister3')
  
#     #cursor.execute("SELECT studstanddivid FROM studstanddivtable where fullname=%s",((studname)))
#     #cursor.execute("SELECT fullname,standardname,divisionname FROM studstanddivtable")
#     cursor.execute("SELECT * FROM studstanddivtable")

  
#     data = cursor.fetchall()
#    #  data2 = cursor2.fetchall()
#    #  data3 = cursor3.fetchall()
#    #  data4 = cursor4.fetchall()
#    #  global records
#    #  print(data2) 
#    #  for records in data:
#     for record in data:
#          tree.insert('',END, values=record[0]+"\t"+record[1]+"\t"+record[2])
            # tree.insert(' ',END, values=record[1]  + " " + record[2] + " " + record[3])
            # tree.insert('',END, values=records[5])
       
   #  for records1 in data1:
   #       tree.insert('',END, values=records1[1])
   #  for records2 in data2:
   #          tree.insert('',END, values=records2)

# def display_records():
#    global tree
#    # name_search = registerid.get()
#    tree.delete(*tree.get_children())
#    connection = pymysql.connect(**db_config)
#    cursor = connection.cursor()
#    #curr = cursor.execute('SELECT registernum, studentid,studentname,adharnumber,fathersname,surname,mothersname,mobileno,address,nationality,mothertongue,dharma,jat,potjat,Birthdate,birthplace,oldschool,Admidate,admistd,studyprogress,behaviour,Schoolleftdate,schoolleftreason,remark,Bankaccountno,Bankname,Bankbranch,Bankifsc,pustaknumber,lcyn,Leavingcertificateissuedate, taluka, jhila,rajya FROM newregister3')
#    cursor.execute("SELECT * FROM studstanddivtable")
#    data = cursor.fetchall()
#    #print(data) 
#    for records in data:
#        tree.insert('', END, values=records)
# def view_record():
#    global studstanddivid,registerid,standardid,divisionid
#    if not tree.selection():
#        mb.showerror('Error!', 'Please select a record to view')
#    else:
#         current_item = tree.focus()
#         values = tree.item(current_item)
#         selection = values["values"]
#         studstanddivid.set(selection[0]),st
# def search_registerid():
   
   
def update():
   
   connection_divisionid = pymysql.connect(**db_config_division)
   cursor_divsionid = connection_divisionid.cursor()
   # cursor_divisionid = connection_registerid.cursor()
   
   
   cursor_divsionid.execute("SELECT divisionid from divisiontable where divisionname=%s",(divisionname.get()))
   # cursor_divisionid.execute("SELECT divisionid from divisiontable where divisionid=%s",(divisionname.get()))

   
   records_divsionid = cursor_divsionid.fetchall()
   # records_divisionid = cursor_registerid.fetchall()

   
   # for record_divisionid in records_divsionid:   
   #    pass
   # divisionid = record_divisionid[0]

   connection_standardid = pymysql.connect(**db_config_standard)
   cursor_standardid = connection_standardid.cursor()
   # cursor_divisionid = connection_registerid.cursor()

   cursor_standardid.execute("SELECT standardid from standardtable where standardname=%s",(standardname.get()))
   # cursor_divisionid.execute("SELECT divisionid from divisiontable where divisionid=%s",(divisionname.get()))

   records_standardid = cursor_standardid.fetchall()
   # records_divisionid = cursor_registerid.fetchall()
   
   # for record_standardid in records_standardid:   
   #    pass
   # standardid = record_standardid[0]

   connection_registerid = pymysql.connect(**db_config_school)
   cursor_registerid = connection_registerid.cursor()
   cursor_registerid.execute("SELECT registerid from newregister3 where fullname=%s",(studentfullname.get()))
   records_registerid = cursor_registerid.fetchall()
   
   connection_update = pymysql.connect(**db_config)
   conn_update = connection_update.cursor()
    # "UPDATE table SET telefonnummer = ? WHERE telefonnummer = ?"
   sql = 'UPDATE studstanddivtable SET standardname=%s,divisionname=%s,registerid=%s,standardid=%s,divisionid=%s where fullname=%s' #36  
   val = (standardname.get(),divisionname.get(),records_registerid,records_standardid,records_divsionid,studentfullname.get())
   conn_update.execute(sql,val)    
   connection_registerid.commit()
   mb.showinfo('Record Updated', f"Record of {studentfullname.get()} was successfully updated")
   
   
      #  global standard
       
      #  standard = record_standardid[0]

# def search_divisionid():
   
   
      #  global division
      #  division = record_divisionid[0]

def add_record():
   
        
      connection_divisionid = pymysql.connect(**db_config_division)
      cursor_divsionid = connection_divisionid.cursor()
      # cursor_divisionid = connection_registerid.cursor()


      cursor_divsionid.execute("SELECT divisionid from divisiontable where divisionname=%s",(divisionname.get()))
      # cursor_divisionid.execute("SELECT divisionid from divisiontable where divisionid=%s",(divisionname.get()))


      records_divsionid = cursor_divsionid.fetchall()
      # records_divisionid = cursor_registerid.fetchall()


      # for record_divisionid in records_divsionid:   
      #    pass
      # divisionid = record_divisionid[0]

      connection_standardid = pymysql.connect(**db_config_standard)
      cursor_standardid = connection_standardid.cursor()
      # cursor_divisionid = connection_registerid.cursor()

      cursor_standardid.execute("SELECT standardid from standardtable where standardname=%s",(standardname.get()))
      # cursor_divisionid.execute("SELECT divisionid from divisiontable where divisionid=%s",(divisionname.get()))

      records_standardid = cursor_standardid.fetchall()
      # records_divisionid = cursor_registerid.fetchall()

      # for record_standardid in records_standardid:   
      #    pass
      # standardid = record_standardid[0]

      connection_registerid = pymysql.connect(**db_config_school)
      cursor_registerid = connection_registerid.cursor()
      cursor_registerid.execute("SELECT registerid from newregister3 where fullname=%s",(studentfullname.get()))
      records_registerid = cursor_registerid.fetchall()


      #add connection
      
      connection_check = pymysql.connect(**db_config)
      conn_check = connection_check.cursor()
      #conn.execute("SELECT * FROM newregister3 where registernum = %s",(register_num.get()))
      #conn_check.execute("SELECT * from studstanddivtable = %s",(studentfullname.get()))
      conn_check.execute("SELECT * FROM studstanddivtable where fullname = %s",(studentfullname.get()))
      records_check = conn_check.fetchone()
      if records_check:
         mb.showinfo("Message","Record already exists")
         studentfullname.focus()
      else:   
       connection_add = pymysql.connect(**db_config)
       conn_add = connection_add.cursor()
   
       sql = "INSERT INTO studstanddivtable(fullname,divisionname,standardname,registerid,standardid,divisionid) VALUES(%s,%s,%s,%s,%s,%s)"
       val = (studentfullname.get(),divisionname.get(),standardname.get(),records_registerid,records_standardid,records_divsionid)
       conn_add.execute(sql,val)
       connection_add.commit()
       mb.showinfo('Record Added', f"Record of {studentfullname.get()} was successfully added")
def recordexists():
     
      connection_record = pymysql.connect(**db_config)
      conn_record = connection_record.cursor()
      #conn.execute("SELECT * FROM newregister3 where registernum = %s",(register_num.get()))
      #conn_check.execute("SELECT * from studstanddivtable = %s",(studentfullname.get()))
      conn_record.execute("SELECT fullname from studstanddivtable")
      records_check = conn_record.fetchall()
      if records_check:
         mb.showinfo("Message","Record already exist")
         studentfullname.focus()
   
         

    




def combobox_insert():
    # connectionname = pymysql.connect(**db_config_school)
    # connname = connectionname.cursor()
    # # connmname = connectionname.cursor()
    # # connlname = connectionname.cursor()
    # connname.execute("SELECT studentname,fathersname,surname FROM newregister3")
    # # connmname.execute("select fathersname from newregister3")
    # # connlname.execute("select surname from newregister3")
    # records= connname.fetchall()
    # print(records)
    db = pymysql.connect(**db_config_school)

    cursor1 = db.cursor()

    cursor1.execute('SELECT fullname FROM newregister3')

    data = []

    for row in cursor1.fetchall():
        data.append(row[0])

    return data
    # recordsmname= connmname.fetchall()
    # recordslname= connlname.fetchall()
    # for record in records:
   #  for recordmname in recordsmname:
   #      for recordlname in recordslname:
       
    



connection1 = pymysql.connect(**db_config_standard)
conn1 = connection1.cursor()
conn1.execute("select standardname from standardtable")
records1= conn1.fetchall()
connection2 = pymysql.connect(**db_config_division)
conn2 = connection2.cursor()
conn2.execute("select divisionname from divisiontable")
records2= conn2.fetchall()


# Creating tkinter window
main = tk.Tk()
main.title('School Management System')
main.geometry('1366x768')
main.config(bg="DarkSeaGreen3")


#display_records()
lf_bg = "DarkSeaGreen3" # bg color for the main
cf_bg = 'PaleGreen' # bg color for the main
studstanddivid=StringVar()
right_frame = Frame(main, bg="Gray35")
right_frame.place(relx=0.69, y=14, relheight=1, relwidth=0.3)

studstanddivid=StringVar()
fullname=StringVar()
standardname=StringVar()
divisionname=StringVar()
studname=StringVar()
name = StringVar()
input_1 = StringVar()
# ttk.Label=Label(main, text="studstanddivid",font=labelfont, bg=lf_bg).place(x=27, y=20)
input_2 = StringVar()
# studstanddivid=Entry(main,width=15,textvariable=studstanddivid,font=entryfont)
input_3 = StringVar()
# studstanddivid.place(x=180,y=20)
global studentfullname
global tree
display_records()

ttk.Label=Label(main, text="student\n  fullname",font=labelfont, bg=lf_bg).place(x=8, y=50)
studentfullname= ttk.Combobox(main, width=20, textvariable=fullname,font=entryfont)
studentfullname.place(x=100,y=60)
studentfullname['values'] = combobox_insert()



#register_num.bind("<Tab>",lambda event: checkemptyregister_num())
# studentfullname.bind("<Return>",lambda event:recordexists())
#studentname.bind('<Return>',lambda event: display_records())
ttk.Label=Label(main, text="standard \n name",font=labelfont, bg=lf_bg).place(x=350, y=60)
standardname = ttk.Combobox(main, width=10, textvariable=standardname,font=entryfont)
standardname.place(x=450,y=60)
standardname['values'] = (records1)
ttk.Label=Label(main, text="division\n name",font=labelfont, bg=lf_bg).place(x=590, y=60)
divisionname = ttk.Combobox(main, width=6, textvariable=divisionname,font=entryfont)
divisionname.place(x=670,y=60)
divisionname['values'] = (records2)
# divisionname.bind("<Return>",lambda event: update())


submit_button=Button(main, text='Submit', font=labelfont,command=add_record, width=10).place(x=15,y=500) 
Update_button = Button(main,text='Update',font=labelfont,command=update, width=10).place(x=15,y=650) 

view_button=Button(main, text='View Record', font=labelfont, command=exit ,width=10).place(x=150,y=650)

# clear_button=Button(main, text='Clear', font=labelfont, command=reset_fields, width=10).place(x=285,y=650)
# search_button=Button(main, text='Search', font=labelfont,command=display_records, width=10).place(x=435,y=650) 

delete_button=Button(main, text='Delete', font=labelfont, command=exit, width=10).place(x=555,y=650)


exit_button=Button(main, text='Exit', font=labelfont, command=main.destroy, width=10).place(x=815,y=650)
# Placing components in the right frame

Label(right_frame, text='Register Records', font=headlabelfont, bg='DarkGreen', fg='LightCyan').pack(side=TOP, fill=X)
tree = ttk.Treeview(right_frame, height=100, selectmode=BROWSE,
                    columns=('studstanddivid','studentname', 'standardname','divisionname'))
X_scroller = Scrollbar(tree, orient=HORIZONTAL, command=tree.xview)
Y_scroller = Scrollbar(tree, orient=VERTICAL, command=tree.yview)
X_scroller.pack(side=BOTTOM, fill=X)
Y_scroller.pack(side=RIGHT, fill=Y)
tree.config(yscrollcommand=Y_scroller.set, xscrollcommand=X_scroller.set)
tree.heading('studstanddivid', text='studstanddivid', anchor=CENTER)
tree.heading('studentname', text='student Name', anchor=CENTER)
tree.heading('standardname', text='Standardname', anchor=CENTER)
tree.heading('divisionname', text='division name', anchor=CENTER)
#tree.heading('aadharnumber', text='Aadharnumber', anchor=CENTER)
tree.column('#0', width=0, stretch=NO, minwidth=100)
tree.column("#1", width=40, stretch=NO,minwidth=0)
tree.column('#2', width=80, stretch=NO,minwidth=0)
tree.column('#3', width=100, stretch=NO,minwidth=0)
# tree1.column('#4', width=120, stretch=NO,minwidth=0)

tree.place(y=30, relwidth=1, relheight=0.9, relx=0)

# Label(right_frame, text='Register Records', font=headlabelfont, bg='DarkGreen', fg='LightCyan').pack(side=TOP, fill=X)
# tree = ttk.Treeview(right_frame, height=100, selectmode=BROWSE,
#                    columns=('studentname', 'standardname','divisionname'))
# X_scroller = Scrollbar(tree, orient=HORIZONTAL, command=tree.xview)
# Y_scroller = Scrollbar(tree, orient=VERTICAL, command=tree.yview)
# X_scroller.pack(side=BOTTOM, fill=X)
# Y_scroller.pack(side=RIGHT, fill=Y)
# tree.config(yscrollcommand=Y_scroller.set, xscrollcommand=X_scroller.set)
# #tree.heading('studstanddivid', text='studstanddivid', anchor=CENTER)
# tree.heading('studentname', text='student Name', anchor=CENTER)
# tree.heading('standardname', text='Standardname', anchor=CENTER)
# tree.heading('divisionname', text='division name', anchor=CENTER)
# #tree.heading('aadharnumber', text='Aadharnumber', anchor=CENTER)
# tree.column('#0', width=0, stretch=NO, minwidth=0)
# tree.column('#1', width=40, stretch=NO,minwidth=0)
# tree.column('#2', width=80, stretch=NO,minwidth=0)
# #tree.column('#3', width=120, stretch=NO,minwidth=0)
# #tree.column('#4', width=120, stretch=NO,minwidth=0)
# tree.place(y=30, relwidth=1, relheight=0.9, relx=0)
display_records()


   

main.mainloop()
