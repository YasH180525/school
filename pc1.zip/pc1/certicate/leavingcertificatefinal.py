from tkinterweb import HtmlFrame
from tkinter import *
import sqlite3
from tkinter import messagebox
from pyscreenshot import grab
from tkPDFViewer import tkPDFViewer as pdf
from pyscreenshot import *
from ctypes import windll
import os

root = Tk() 
root.title("Leaving Certificate")
root.resizable(False,False)
global Input_1

# def insertrecord():
search_record = StringVar()
fname = StringVar()

def printer():
    from pyscreenshot import grab

    im = grab(bbox=(0, 40, 850, 860))
    im.show()
    # im.close()
    os.close("Photos")
    save = im.save("C:\\Users\\Yash\\Desktop\\" + Input_general_register.get()+".png")
    print(save)
    os.startfile("C:\\Users\\Yash\\Desktop\\" + Input_general_register.get()+".png")

def search_record():
    connection = sqlite3.connect("C:\\Users\\Yash\\Desktop\\26062023\\school.db")
    conn = connection.cursor()
    print("Connected")
    record_id = Input_general_register.get()
    conn.execute("SELECT * FROM newregister3 where registernum = " + record_id)
    # messagebox.showinfo("Message","Database records selected")
    records = conn.fetchall()
    print("Fetched")
    for record in records:
        print("Inserting Records!!!!!!")
        global Label_studentid
        global Label_uid
        global Label_fname
        global Label_mothersname
        global Label_nationality
        global Label_mothertongue
        global Label_dharma
        global Label_jat
        global Label_potjat
        global Label_birthplace
        global Label_oldschool
        global Label_admindate
        global Label_studyprogress
        global Label_behaviour
        global Label_schoolleftdate
        global Label_schoolleftreason
        global Label_remark
        Label_studentid = Label(root,text=record[1],font=20,bg="white")
        Label_studentid.place(x=200,y=250)
        Label_uid = Label(root,text=record[2],font=20,bg="white")
        Label_uid.place(x=200,y=285)
        Label_fname = Label(root,text=record[35],font=30,bg="white")
        Label_fname.place(x=200,y=315)
        Label_mothersname = Label(root,text=record[7],font=30,bg="white")
        Label_mothersname.place(x=200,y=365)
        Label_nationality = Label(root,text=record[10],font=30,bg="white")
        Label_nationality.place(x=200,y=400)
        Label_mothertongue = Label(root,text=record[11],font=30,bg="white")
        Label_mothertongue.place(x=470,y=400)
        Label_dharma = Label(root,text=record[12],font=30,bg="white")
        Label_dharma.place(x=230,y=438)
        Label_jat = Label(root,text=record[13],font=30,bg="white")
        Label_jat.place(x=380,y=438)
        Label_potjat = Label(root,text=record[14],font=30,bg="white")
        Label_potjat.place(x=550,y=438)
        Label_birthplace = Label(root,text=record[16]+","+record[32]+","+record[33]+","+record[34],font=30,bg="white")
        Label_birthplace.place(x=200,y=488)
        Label_oldschool = Label(root,text=record[17],font=30,bg="white")
        Label_oldschool.place(x=200,y=600)
        Label_admindate = Label(root,text=record[18],font=30,bg="white")
        Label_admindate.place(x=200,y=630)
        Label_studyprogress = Label(root,text=record[19],font=30,bg="white")
        Label_studyprogress.place(x=200,y=668)
        Label_behaviour = Label(root,text=record[20],font=30,bg="white")
        Label_behaviour.place(x=510,y=667)
        Label_schoolleftdate = Label(root,text=record[22],font=30,bg="white")
        Label_schoolleftdate.place(x=200,y=700)
        Label_schoolleftreason = Label(root,text=record[23],font=30,bg="white")
        Label_schoolleftreason.place(x=200,y=775)
        Label_remark = Label(root,text=record[24],font=30,bg="white")
        Label_remark.place(x=200,y=805)

def destroylabels():
    Label_studentid.destroy()
    Label_uid.destroy()
    Label_fname.destroy() 
    Label_mothersname.destroy()
    Label_mothertongue.destroy()
    Label_nationality.destroy()
    Label_dharma.destroy()
    Label_jat.destroy()
    Label_potjat.destroy()
    Label_birthplace.destroy()
    Label_oldschool.destroy()
    Label_admindate.destroy()
    Label_studyprogress.destroy()
    Label_behaviour.destroy()
    Label_schoolleftdate.destroy()
    Label_schoolleftreason.destroy()
    Label_remark.destroy()

global Input_fname
Input_fname = StringVar()
root.geometry("1000x900+0+0")
# root.geometry("1920x1080")
root.resizable(False,False)


#Html Frame
frame = HtmlFrame(root) #create HTML rootr
frame.config()
frame.load_file("file:///C:/Users/Yash/Desktop/26062023/lcert (2).html")
frame.pack(fill="both", expand=True) #attach the HtmlFrame widget to the parent window
#Up Section
Label_suchana = Label(root,text="सूचना:१) शाळा सोडल्याचे  दाखल्यामध्ये अनधिकृतरित्या बदल केल्यlस  संबधितावर कायदेशीर कारवाई करण्यiत येईल.")
Label_suchana.config(bg="white")
Label_suchana.place(x=10,y=20)
Label_schoolname = Label(root,text="बापूसाहेब पवार  कन्या शाळा ")
Label_schoolname.config(bg="white")
Label_schoolname.place(x=150,y=50)
Label_school_address = Label(root,text="३८०-ड,भवानी पेठ,पुणे,जि.पुणे-४११०४२.")
Label_school_address.config(bg="white")
Label_school_address.place(x=10,y=90)
Input_school_address = Entry(root,font=20,width=30)
Input_school_address.place(x=200,y=90)
Label_mobilenum = Label(root,text="फोन:०२०-२६४५४०५५")
Label_mobilenum.config(bg="white")
Label_mobilenum.place(x=520,y=90)
Label_schoolnum = Label(root,text="शाळेचा मान्यता क्रमांक-३९, दि.२२ फेब्रुवारी१९६१")
Label_schoolnum.config(bg="white")
Label_schoolnum.place(x=10,y=130)
Input_schoolnum = Entry(root,font=20,width=30)
Input_schoolnum.place(x=250,y=130)
Label_ssc_indexno = Label(root,text="s.s.c index No.-11-15-040")
Label_ssc_indexno.place(x=480,y=130)
Label_ssc_indexno.config(bg="white")
Label_udisenum = Label(root,text="यु.डायस.क्र.-२७२५१८००३०९")
Label_udisenum.place(x=10,y=170)
Label_udisenum.config(bg="white")
Input_udisenum = Entry(root,font=20)
Input_udisenum.place(x=150,y=170)
Input_udisenum.config(bg="white")
Label_medium = Label(root,text="माध्यम-मराठी ")
Label_medium.place(x=350,y=170)
Label_medium.config(bg="white")
Label_board = Label(root,text="बोर्ड-पुणे")
Label_board.place(x=450,y=170)
Label_board.config(bg="white")
Input_board = Entry(root,font=20)
Input_board.place(x=500,y=170)
Label_dakhlanum = Label(root,text="दाखला क्रमांक.:")
Label_dakhlanum.place(x=10,y=210)
Label_dakhlanum.config(bg="white")
Input_dakhlanum = Entry(root,font=20)
Input_dakhlanum.place(x=90,y=210)
Label_school_left_dakhla = Label(root,text="शाळा सोडल्याचा दाखला")
Label_school_left_dakhla.place(x=280,y=210)
Label_school_left_dakhla.config(bg="white")
Label_general_register = Label(root,text="जनरल रजिस्टर क्रमांक")
Label_general_register.place(x=430,y=210)
Label_general_register.config(bg="white")
Input_general_register = Entry(root,font=20,width=5)
Input_general_register.place(x=550,y=210)
Input_general_register.bind('<Return>',lambda event:search_record())
Input_general_register.focus()





student_id = Label(root,text="सटुडंट आय.डी:")
student_id.place(x=15,y=250)
student_id.config(bg="white")
uid = Label(root,text="यु.आय.डी")
uid.place(x=15,y=290)
uid.config(bg="white")
fullname = Label(root,text="१)विद्यार्थ्यांचे संपुर्ण नाव\n(नाव-वडिलांचे नाव-आडनाव)")
fullname.place(x=10,y=320)
fullname.config(bg="white")
mothers_name = Label(root,text="२) आईचे नाव")
mothers_name.place(x=15,y=360)
mothers_name.config(bg="white")
state = Label(root,text="३) राष्ट्रीयत्व")
state.place(x=15,y=400)
state.config(bg="white")
mothertongue = Label(root,text="४) मातृभाषा")
mothertongue.place(x=400,y=400)
mothertongue.config(bg="white")
dharma_jat_potjat = Label(root,text="५) धर्म, जात, पोट जात")
dharma_jat_potjat.place(x=10,y=440)
dharma_jat_potjat.config(bg="white")
dharma = Label(root,text="धर्म-")
dharma.place(x=200,y=440)
dharma.config(bg="white")
jat = Label(root,text="जात-")
jat.place(x=350,y=440)
jat.config(bg="white")
pot_jat = Label(root,text="पोट जात-")
pot_jat.place(x=500,y=440)
pot_jat.config(bg="white")
birthplace = Label(root,text="६)जन्मस्थळ(गाव/शहर/तालुका\nजिल्हा,राज्य,देश)")
birthplace.place(x=10,y=488)
birthplace.config(bg="white")
birthdate = Label(root,text="७) जन्म दिनांक(इ.सनाप्रमाणे)")
birthdate.place(x=10,y=530)
birthdate.config(bg="white")
birthdate_letters = Label(root,text="८)  जन्म दिनांक(अक्षरी)")
birthdate_letters.place(x=10,y=565)
birthdate_letters.config(bg="white")
previous_school = Label(root,text="९)या शाळेत येण्यापूर्वीची शाळा व इयत्ता")
previous_school.place(x=10,y=600)
previous_school.config(bg="white")
entry_date = Label(root,text="१०) या शाळेत प्रवेश घेतल्याचा दिनांक")
entry_date.place(x=10,y=630)
entry_date.config(bg="white")
studyprogress = Label(root,text="११)अभ्यासातील प्रगती")
studyprogress.place(x=10,y=668)
studyprogress.config(bg="white")
behaviour = Label(root,text="१२)वर्तणूक-")
behaviour.place(x=450,y=668)
behaviour.config(bg="white")
schoolleft_date = Label(root,text="१३)शाळा सोडल्याचा दिनांक")
schoolleft_date.place(x=10,y=700)
schoolleft_date.config(bg="white")
standard = Label(root,text="१४)कोणत्या इयत्तत शिकत होता व\n केव्हापासून(अ री व अंकी)")
standard.place(x=10,y=735)
standard.config(bg="white")
schoolleft_reason = Label(root,text="१५)शाळा सोडल्याचे कारण)")
schoolleft_reason.place(x=10,y=775)
schoolleft_reason.config(bg="white")
remark = Label(root,text="१६)शेरा")
remark.place(x=10,y=805)
remark.config(bg="white")
Label_footer = Label(root,text="दाखला देण्यात येतो  की, वरील माहिती शाळेतील जनरल रजिस्टर न.१  प्रमाणे आहे. दाखला दिल्याची तारीख: ")
Label_footer.place(x=15,y=840)
Label_footer.config(bg="white")




Button_1 = Button(root,text="Clear",command=destroylabels)
Button_1.place(x=10,y=870)
root.bind('<Control-p>',lambda event: printer())
root.mainloop()