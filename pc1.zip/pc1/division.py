from tkinter import *   #support the label and entry input
import tkinter.messagebox as mb   #support  the messagebox 
from tkcalendar import DateEntry  # pip install tkcalendar
from tkinter import messagebox
import tkinter.ttk as ttk   #support the treeview and ttk
import webbrowser
import sqlite3  #support sqlite database
from tkcalendar import DateEntry  # pip install tkcalendar
import tkinter.messagebox as tkMessageBox
import pymysql
#==============================================================================================================
# Creating the universal font variables
headlabelfont = ("Noto Sans CJK TC", 15, 'bold')
labelfont = ('Helvetica', 14)
entryfont = ('Helvetica', 12)

db_config = {
    "host": "localhost",
    "user": "pc1",
    "password": "1234",
    "database": "subject",
}
#====================================================================================================================
connector=pymysql.connect(**db_config)
cursor = connector.cursor()
cursor.execute(
"CREATE TABLE IF NOT EXISTS DIVISIONTABLE (DIVISIONID INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL,DIVISIONNAME VARCHAR(100) )"
)

prevent = False  #submitt and update one click event this variable are used

print("hello")
#==================================================================================================================

# Creating the functions
def reset_fields():
   global divisionname_strvar
   for i in ['divisionname_strvar']:
       exec(f"{i}.set('')")
       SEARCH.set("")
#==================================================================================================================       
def reset_form():
   global tree
   tree.delete(*tree.get_children())
   reset_fields()
#==================================================================================================================
def display_records():
   tree.delete(*tree.get_children())
   connection = pymysql.connect(**db_config)
   conn = connection.cursor()
   conn.execute('SELECT * FROM DIVISIONTABLE')
   data = conn.fetchall()
   for records in data:
       tree.insert('', END, values=records)
##########doubleclick code stared#################


       tree.bind("<Double-1>",OnDoubleClick)
def OnDoubleClick(self):
    global prevent  
    current_item = tree.focus()
    values = tree.item(current_item)
    selection = values["values"]
    divisionname_strvar.set(selection[1])

    prevent = True

##########################doubleclick code ended#################


def add_record():
   global divisionname_strvar
   global prevent  
   divisionname=divisionname_strvar.get()
   if not divisionname  :
       mb.showerror('Error!', "Please fill all the missing fields!!")
   else:
        if prevent == False :            
            connection = pymysql.connect(**db_config)
            conn = connection.cursor()
            conn.execute(
           'INSERT INTO DIVISIONTABLE (DIVISIONNAME) VALUES (%s)', (divisionname)
           )
            connection.commit()
            mb.showinfo('Record added', f"Record of {divisionname} was successfully added")
        else : 
            current_item = tree.focus()
            values = tree.item(current_item)
            selection = values["values"] 
            connection = pymysql.connect(**db_config)
            conn = connection.cursor()
            #connector.execute('UPDATE TEACHERTABLE2 SET TEACHERFULLNAME=?,TEACHERBIRTHDATE=?,TEACHERCASTE=?,TEACHERJOD=?,TEACHERPFNUMBER=?,TEACHERRETIREDATE=?,TEACHERUSERNAME=? WHERE TEACHERID=? ',(teacherfullname,teacherBirthdate,teachercaste,teacherJod,teacherpfnumber,teacherretiredate,teacherusername, selection[0]))  
            sql = 'UPDATE DIVISIONTABLE SET  divisionname=%s WHERE DIVISIONID=%s'
            val = (divisionname, selection[0])
            conn.execute(sql,val)
            connection.commit()
            mb.showinfo("Message","Updated successfully")     
    
        reset_fields()
        display_records()
        prevent = False
#===================================================================================================================        
def remove_record():
   if not tree.selection():
         mb.showerror('Error!', 'Please select an item from the database')
   else:
        result = tkMessageBox.askquestion('Confirm', 'Are you sure you want to delete this record?',
                                          icon="warning")
        if result == 'yes':
          
         current_item = tree.focus()
         values = tree.item(current_item)
         selection = values["values"]
         tree.delete(current_item)
         connection = pymysql.connect(**db_config)
         conn = connection.cursor() 
         conn.execute('DELETE FROM DIVISIONTABLE WHERE DIVISIONID=%d' % selection[0])
         connection.commit()
         mb.showinfo('Done', 'The record you wanted deleted was successfully deleted.')
         display_records()
#===============================================================================================================
def view_record():
   global divisionname_strvar
   global prevent
   if not tree.selection():
       mb.showerror('Error!', 'Please select a record to view')
   else:
        current_item = tree.focus()
        values = tree.item(current_item)
        selection = values["values"]
        divisionname_strvar.set(selection[1])

        prevent = True
#===================================================================================================================
def clear():
        divisionname_strvar.delete(0,END)
#===================================================================================================================      
def update():
    connector=pymysql.connect(**db_config)
    global divisionname_strvar
    divisionname =   divisionname_strvar.get()
    
    current_item = tree.focus()
    values = tree.item(current_item)
    selection = values["values"] 
    connection = pymysql.connect(**db_config)
    conn = connection.cursor()
    
    sql = 'UPDATE DIVISIONTABLE SET  divisionname=%s WHERE DIVISIONID=%s '
    val = (divisionname, selection[0])
    conn.execute(sql,val)
    connection.commit()
    mb.showinfo("Message","Updated successfully")
  
    reset_fields()
    #refresh table data
    display_records()
#===============================================================================================================================================    
def SearchRecord():
    #open database
    connection=pymysql.connect(**db_config)
    conn = connection.cursor()
     
    #checking search text is empty or not
    if SEARCH.get() != "":
        #clearing current display data
        tree.delete(*tree.get_children())
        #select query with where clause
        conn.execute("select divisionid,divisionname from divisiontable where divisionname like %s order by divisionname ",("%{}%".format(SEARCH.get()),))
               #fetch all matching records
        fetch = conn.fetchall()
        #loop for displaying all records into GUI
        for data in fetch:
            tree.insert('', 'end', values=(data))
        conn.close()
        # reset_fields()
        connection.close()
#==============================================================================================================================================
 # form Design     

main = Tk()
main.title('School Management System')
main.geometry('1366x768')
main.config(bg="DarkSeaGreen3")
#main.resizable(0, 0)
# Creating the background and foreground color variables1
lf_bg = 'DarkSeaGreen3' # bg color for the left_frame
cf_bg = 'DarkSeaGreen3' # bg color for the center_frame
#================================================================================================================
# Creating the StringVar or IntVar variables
divisionname_strvar = StringVar()
search = StringVar()
SEARCH=StringVar()
#=================================================================================================================
# Placing the components in the main window
Label(main, text="DIVISION FORM", font=headlabelfont, bg='DarkSeaGreen3').pack(side=TOP, fill=X)
left_frame = Frame(main, bg=lf_bg)
left_frame.place(x=0, y=30, relheight=1, relwidth=0.2)
center_frame = Frame(main, bg=cf_bg)
center_frame.place(relx=0.2, y=30, relheight=1, relwidth=0.2)
right_frame = Frame(main, bg="DarkSeaGreen3")
right_frame.place(relx=0.4, y=30, relheight=0.9, relwidth=0.5)
# Placing components in the left frame
lbl_txtsearch = Label(center_frame, text="Enter name to Search", font=('verdana', 10),bg=lf_bg)
lbl_txtsearch.pack()
#==========================================================================================================================
    #creating search entry
search = Entry(center_frame, textvariable=SEARCH, font=('verdana', 15), width=10)
search.pack(side=TOP, padx=10, fill=X)
btn_search = Button(center_frame, text="Search", borderwidth=3, command=SearchRecord) 
btn_search.place(relx=0.4, rely=0.1)
btn_viewall=Button(center_frame, text='View All', font=('verdana', 10), borderwidth=3, command=display_records, width=8).place(relx=0.4, rely=0.14)
#================================================================================================================
# Placing components in the left frame
Label(left_frame, text="Division Name", font=labelfont, bg=lf_bg).place(relx=0.175, rely=0.05)
divisionname = Entry(left_frame, width=19, textvariable=divisionname_strvar, font=entryfont)
divisionname.place(x=20, rely=0.1)
divisionname.bind("<Return>",lambda event: add_record())
#=================================================================================================================
Button(left_frame, text='Submit', font=labelfont, borderwidth=3,command=add_record, width=10).place(relx=0.1,rely=0.25)
Button(left_frame, text='View Record', font=labelfont,  borderwidth=3,command=view_record, width=10).place(relx=0.1, rely=0.35)
Button(left_frame, text='Clear Fields', font=labelfont,  borderwidth=3,command=reset_fields, width=10).place(relx=0.1, rely=0.45)
Button(left_frame, text='Delete', font=labelfont,  borderwidth=3,command=remove_record, width=10).place(relx=0.1, rely=0.55)
Button(left_frame, text='Exit', font=labelfont,  borderwidth=3,command=main.destroy, width=10).place(relx=0.1, rely=0.65)
#=================================================================================================================
# Placing components in the center frame
Label(right_frame, text='Division Records', font=headlabelfont, bg='DarkSeaGreen3', fg='LightCyan').pack(side=TOP, fill=X)
tree = ttk.Treeview(right_frame, height=100, selectmode=BROWSE,
                   columns=('Division ID','Division Name'))
X_scroller = Scrollbar(tree, orient=HORIZONTAL, command=tree.xview)
Y_scroller = Scrollbar(tree, orient=VERTICAL, command=tree.yview)
X_scroller.pack(side=BOTTOM, fill=X)
Y_scroller.pack(side=RIGHT, fill=Y)
tree.config(yscrollcommand=Y_scroller.set, xscrollcommand=X_scroller.set)
tree.heading('Division ID', text='ID', anchor=CENTER)
tree.heading('Division Name', text='Division Name', anchor=CENTER)

#tree.heading('maxstudcount', text='Maxstudcount', anchor=CENTER)
tree.column('#0', width=0, stretch=NO)
tree.column('#1', width=40, stretch=NO)
tree.place(y=30, relwidth=1, relheight=0.9, relx=0)
display_records()
#================================================================================================================
# Finalizing the GUI window
main.update()
main.mainloop()
#=================================================================================================================

