from tkinter import *
import tkinter.messagebox as tkMessageBox
import sqlite3
import pymysql
import os
from tkinter import messagebox
from PIL import Image ,ImageTk
root = Tk()
root.title("My Software.com")
root.config(bg="DarkSeaGreen3") 
width = 1366
height = 768
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width/2) - (width/2)
y = (screen_height/2) - (height/2)
root.geometry("%dx%d+%d+%d" % (width, height, x, y))
#=======================================VARIABLES============================================================================
USERNAME = StringVar()
PASSWORD = StringVar()
FIRSTNAME = StringVar()
LASTNAME = StringVar()

db_config = {
    "host": "localhost",
    "user": "pc1",
    "password": "1234",
    "database": "db_member",
}
#password=StringVar()
#=======================================METHODS==============================================================================
def Database():
   
    connection = pymysql.connect(**db_config)
    conn = connection.cursor()
    conn.execute("CREATE TABLE IF NOT EXISTS `member` (mem_id INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL, username VARCHAR(100), password VARCHAR(100), firstname VARCHAR(100), lastname VARCHAR(100))")
def Exit():
    result = tkMessageBox.askquestion('System', 'Are you sure you want to exit?', icon="warning")
    if result == 'yes':
        root.destroy()
        exit()
def show_and_hide():
    global password
    if password['show'] == '*':
       password['show'] = ''
    else:
       password['show'] = '*'



def LoginForm():
    global LoginFrame
    global lbl_result1
    global password 
    global img,img1 
    global username
    password = StringVar()
    LoginFrame = Frame(root,bg="DarkSeaGreen3" )
    LoginFrame.pack(side=TOP, pady=80)
    lbl_username = Label(LoginFrame, text="Username:",bg="DarkSeaGreen3" ,font=('arial', 25), bd=18)
    lbl_username.grid(row=1)

    lbl_password = Label(LoginFrame, text="Password:",bg="DarkSeaGreen3" , font=('arial', 25), bd=18)
    lbl_password.grid(row=2)
    lbl_result1 = Label(LoginFrame, text="",bg="DarkSeaGreen3" , font=('arial', 18))
    lbl_result1.grid(row=3, columnspan=2)
    username = Entry(LoginFrame, font=('arial', 20),bg="white" , textvariable=USERNAME, width=15)
    username.grid(row=1, column=1)
    username.bind("<Return>",lambda event: nextentrypassword())
    password = Entry(LoginFrame, font=('arial', 20),bg="white" , textvariable=PASSWORD, width=15, show="*")
    password.grid(row=2,column=1)
    password.bind("<Return>",lambda event: Login()) 
    btn_login = Button(LoginFrame, text="Login", font=('arial', 18),bg="DarkSeaGreen3" , width=35, command=Login)
    btn_login.grid(row=4, columnspan=2, pady=20)
    lbl_register = Label(LoginFrame, text="NewRegister", bg="DarkSeaGreen3" ,fg="Blue", font=('arial', 12))
    lbl_register.grid(row=0, sticky=W)
    checkBox_showPassword = Checkbutton(root, text="show password", bg='DarkSeaGreen3',fg='red',
                                    font=('verdana',14), command=show_and_hide)
    checkBox_showPassword.place(x=1020,y=170)
 
    #  # Create a Label Widget to display the text or Image
    image_names="images\\user-login.ico"
    img = ImageTk.PhotoImage(Image.open(image_names))
    label = Label(root, image = img)
    label.place(x=420,y=110)
    image_names1="images\\key.ico"
    img1 = ImageTk.PhotoImage(Image.open(image_names1))
    label1 = Label(root, image = img1)
    label1.place(x=420,y=200)
    
    lbl_register.bind('<Button-1>', ToggleToRegister)


def show_and_hide():
    global password
    if password['show'] == '*':
       password['show'] = ''
    else:

        password['show'] = '*'   

def nextentrypassword():
    password.focus()
def nextentryfirstname():
    firstname.focus()
def nextentrylastname():
    lastname.focus()      


def RegisterForm():
    global RegisterFrame, lbl_result2,img,result
    global password
    global password_register
    global firstname,lastname
    RegisterFrame = Frame(root,bg="DarkSeaGreen3")
    RegisterFrame.place(x=475,y=90)
    lbl_username = Label(RegisterFrame, text="Username:", bg="DarkSeaGreen3", font=('arial', 18), bd=18)
    lbl_username.grid(row=1)
    lbl_password = Label(RegisterFrame, text="Password:", bg="DarkSeaGreen3" ,font=('arial', 18), bd=18)
    lbl_password.grid(row=2)
    lbl_firstname = Label(RegisterFrame, text="Firstname:",bg="DarkSeaGreen3" , font=('arial', 18), bd=18)
    lbl_firstname.grid(row=3)
    lbl_lastname = Label(RegisterFrame, text="Lastname:",bg="DarkSeaGreen3" , font=('arial', 18), bd=18)
    lbl_lastname.grid(row=4)
    lbl_result2 = Label(RegisterFrame, text="",bg="DarkSeaGreen3" , font=('arial', 18))
    lbl_result2.grid(row=5, columnspan=2)
    username = Entry(RegisterFrame, font=('arial', 20),bg="white" , textvariable=USERNAME, width=15)
    username.grid(row=1, column=1)
    username.bind("<Return>",lambda event: nextentrypassword())

    password = Entry(RegisterFrame, font=('arial', 20),bg="white" , textvariable=PASSWORD, width=15, show="*")
    password.grid(row=2, column=1)
    password.bind("<Return>",lambda event: nextentryfirstname())
    firstname = Entry(RegisterFrame, font=('arial', 20),bg="white" , textvariable=FIRSTNAME, width=15)
    firstname.grid(row=3, column=1)
    firstname.bind("<Return>",lambda event: nextentrylastname())
    lastname = Entry(RegisterFrame, font=('arial', 20),bg="white" , textvariable=LASTNAME, width=15)
    lastname.grid(row=4, column=1)
    lastname.bind("<Return>",lambda event: NewRegister())
    btn_login = Button(RegisterFrame, text="Register", font=('arial', 18), bg="DarkSeaGreen3" ,width=35, command=NewRegister)
    btn_login.grid(row=6, columnspan=2, pady=20)
    lbl_login = Label(RegisterFrame, text="Login", bg="DarkSeaGreen3" ,fg="Blue", font=('arial', 12))
    lbl_login.grid(row=0, sticky=W)
    
    lbl_login.bind('<Button-1>', ToggleToLogin)

def ToggleToLogin(event=None):
    RegisterFrame.destroy()
    LoginForm()

def ToggleToRegister(event=None):
    LoginFrame.destroy()
    RegisterForm()
def ToggleToChange(event=None):
    LoginFrame.selection_own()
    LoginForm()
def show_and_hide():
    global password
    if password['show'] == '*':
       password['show'] = ''
    else:
       password['show'] = '*'
def NewRegister():
    Database()
    if USERNAME.get == "" or PASSWORD.get() == "" or FIRSTNAME.get() == "" or LASTNAME.get == "":
        lbl_result2.config(text="Please complete the required field!",bg="DarkSeaGreen3" , fg="orange")
    else:
        connection = pymysql.connect(**db_config)
        conn = connection.cursor()
        conn.execute("SELECT * FROM member WHERE username = %s", (USERNAME.get(),))
        if conn.fetchone() is not None:
            lbl_result2.config(text="Username is already taken", bg="DarkSeaGreen3" ,fg="red")
        else:
            sql = "INSERT INTO member (username, password, firstname, lastname) VALUES(%s,%s,%s,%s)" 
            val = (USERNAME.get(), PASSWORD.get(), FIRSTNAME.get(), LASTNAME.get())
            conn.execute(sql,val)
            connection.commit()
            USERNAME.set("")
            PASSWORD.set("")
            FIRSTNAME.set("")
            LASTNAME.set("")
            
            lbl_result2.config(text="Successfully Created!",bg="DarkSeaGreen3"  ,fg="black")




def Login():
    Database()
    if USERNAME.get == "" or PASSWORD.get() == "":
        lbl_result1.config(text="Please complete the required field!", fg="orange")
    else:
        connection = pymysql.connect(**db_config)
        conn = connection.cursor()
        conn.execute("SELECT * FROM member WHERE username = %s and password = %s", (USERNAME.get(), PASSWORD.get()))
        if conn.fetchone() is not None:
            lbl_result1.config(text="You Successfully Login", fg="blue")
            os.startfile("mainmenu")
            msg = messagebox.showinfo("Message","Opening Mainmenu")
            
            root.destroy()
          
        else:
            lbl_result1.config(text="Invalid Username or password", fg="red")


LoginForm()

#========================================MENUBAR WIDGETS==================================
menubar = Menu(root)
filemenu = Menu(menubar, tearoff=0)
filemenu.add_command(label="Exit", command=root.destroy)
menubar.add_cascade(label="File", menu=filemenu)
root.config(menu=menubar)



#========================================INITIALIZATION===================================
if __name__ == '__main__':
    root.mainloop()
   
