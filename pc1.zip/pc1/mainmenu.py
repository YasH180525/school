#######Declaration of the  packages
from tkinter import *
import os
######  main  programs started   ################ 
mainmenu=Tk()
mainmenu.geometry("1366x768")
mainmenu.title("Menu")
mainmenu.config(bg="DarkSeaGreen3")
Tk().withdraw()
def RegisterCall():    
    os.startfile("register")

def standardcall():
    os.startfile("standard")

def standardcall():
    os.startfile("di")


def backup():
    os.startfile("backup.py")

Button_menu1 = Button(mainmenu, bg="DarkSeaGreen3", font= 'calibri',text="Registration Entry",command=RegisterCall, width=30)
Button_menu1.place(x=450,y=50)
Button_menu2 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="Standard Master",command=standardcall,width=30)
Button_menu2.place(x=450,y=100)
Button_menu3 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="Division Master",width=30)
Button_menu3.place(x=450,y=150)
Button_menu4 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="Subject Master",width=30)
Button_menu4.place(x=450,y=200)
Button_menu5 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="Teacher Master",width=30)
Button_menu5.place(x=450,y=250)
Button_menu6 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="Class Teacher Master",width=30)
Button_menu6.place(x=450,y=300)
Button_menu7 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="Standard Subject Master",width=30)
Button_menu7.place(x=450,y=350)
Button_menu8 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="Student Standard Division Master",width=30)
Button_menu8.place(x=450,y=400)
Button_menu9 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="Presenty View",width=30)
Button_menu9.place(x=750,y=50)
Button_menu10 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="Bonfide Certificate",width=30)
Button_menu10.place(x=750,y=100)
Button_menu11 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="Leaving Certificate" ,width=30)
Button_menu11.place(x=750,y=150)
Button_menu12 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="UDISE Reports " ,width=30)
Button_menu12.place(x=750,y=200)
Button_menu13 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="Result" ,width=30)
Button_menu13.place(x=750,y=250)
Button_menu14 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="Backup" ,width=30,command=backup)
Button_menu14.place(x=450,y=580)
Button_menu15 = Button(mainmenu,bg="DarkSeaGreen3",font= 'calibri',text="END" ,width=30)
Button_menu15.place(x=450,y=630)



mainmenu.mainloop()

