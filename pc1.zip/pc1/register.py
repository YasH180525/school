from tkinter import *   #support the label and entry input
import tkinter.messagebox as mb   #support  the messagebox 
import datetime
from datetime import date
from tkcalendar import DateEntry  # pip install tkcalendar
from tkinter import messagebox
import tkinter.ttk as ttk   #support the treeview and ttk
import sqlite3  #support sqlite database
import tkinter.messagebox as tkMessageBox
from PIL import Image, ImageTk  # image and photo capture process

import cv2 #webcamera on
import os
import pymysql
import pandas as pd  #it is used in reports xlsxwriter
import speech_recognition as sr
import pyttsx3
import pandas.io.sql as sql
import shutil
#===============================================================================================================================================================================================================================================================================================================================================
# Creating the universal font variables
headlabelfont = ("Times New Roman", 15, 'bold')
labelfont = ('Helvetica', 14)
entryfont = ('Helvetica', 12)
#==========================================================================================================================================================================================================================================================================================================================================================
#connector = sqlite3.connect('school.db')
db_config = {
    "host": "localhost",
    "user": "pc1",
    "password": "1234",
    "database": "school",
}
connector = pymysql.connect(**db_config)
conn = connector.cursor()
conn.execute("CREATE TABLE if not exists newregister3 (registerid integer primary key  NOT NULL,registernum VARCHAR(100) ,studentid VARCHAR(100),adharnumber VARCHAR(100),studentname VARCHAR(100),fathersname VARCHAR(100),surname VARCHAR(100),mothersname VARCHAR(100),mobileno VARCHAR(100),address VARCHAR(100),nationality VARCHAR(100),mothertongue VARCHAR(100),dharma VARCHAR(100),jat VARCHAR(100),potjat VARCHAR(100),Birthdate VARCHAR(100),birthplace VARCHAR(100),oldschool VARCHAR(100),admidate VARCHAR(100),admistd VARCHAR(100),studyprogress VARCHAR(100),behaviour VARCHAR(100),schoolleftdate VARCHAR(100),schoolleftreason VARCHAR(100),remark VARCHAR(100),Bankaccountno VARCHAR(100),Bankname VARCHAR(100),Bankbranch VARCHAR(100),Bankifsc VARCHAR(100),pustaknumber VARCHAR(100),lcyn integer,leavingcertificateissuedate VARCHAR(100),taluka VARCHAR(100),jhila VARCHAR(100),rajya VARCHAR(100),fullname VARCHAR(100))")

global Prevent,filename
prevent = False
print(prevent)


#=================================================================================================================================================================================================================================================================================================================================================================================================

def reset_fields():
   global registernum_strvar,studentid_strvar,adharnumber_strvar,studentname_strvar,fathersname_strvar,surname_strvar,mothersname_strvar,mobileno_strvar,address_strvar,nationality_strvar,mothertongue_strvar,dharma_strvar,jat_strvar,potjat_strvar,birthdate,birthplace_strvar,oldschool_strvar,admidate,admistd_strvar,studyprogress_strvar,behaviour_strvar,schoolleftdate,schoolleftreason_strvar,remark_strvar,Bankaccountno_strvar,Bankname_strvar,Bankbranch_strvar,Bankifsc_strvar,pustaknumber_strvar,lcyn_Intvar,leavingcertificateissuedate,taluka_strvar,jhila_strvar,rajya_strvar
   #global registernum_strvar,studentid_strvar,adharnumber_strvar,studentname_strvar,fathersname_strvar,surname_strvar,mothersname_strvar,mobileno_strvar,address_strvar,nationality_strvar,mothertongue_strvar,dharma_strvar,jat_strvar,potjat_strvar,birthdate,birthplace_strvar,oldschool_strvar,admidate,admistd_strvar,studyprogress_strvar,behaviour_strvar,schoolleftdate,schoolleftreason_strvar,remark_strvar,Bankaccountno_strvar,Bankname_strvar,Bankbranch_strvar,Bankifsc_strvar,pustaknumber_strvar,lcyn_Intvar,leavingcertificateissuedate
  # for i in ['registernum_strvar', 'studentid_strvar','adharnumber_strvar','studentname_strvar','fathersname_strvar','surname_strvar','mothersname_strvar','mobileno_strvar','address_strvar','nationality_strvar','mothertongue_strvar','dharma_strvar','jat_strvar','potjat_strvar','birthplace_strvar','oldschool_strvar','admistd_strvar','studyprogress_strvar','behaviour_strvar','schoolleftreason_strvar','remark_strvar','Bankaccountno_strvar','Bankname_strvar','Bankbranch_strvar','Bankifsc_strvar','lcyn_Intvar','pustaknumber_strvar' ]:
   #   exec(f"{i}.set('')") 
   for i in ['registernum_strvar', 'studentid_strvar','adharnumber_strvar','studentname_strvar','fathersname_strvar','surname_strvar','mothersname_strvar','mobileno_strvar','address_strvar','nationality_strvar','mothertongue_strvar','dharma_strvar','jat_strvar','potjat_strvar','birthplace_strvar','oldschool_strvar','admistd_strvar','studyprogress_strvar','behaviour_strvar','schoolleftreason_strvar','remark_strvar','Bankaccountno_strvar','Bankname_strvar','Bankbranch_strvar','Bankifsc_strvar','lcyn_Intvar','pustaknumber_strvar' ,'taluka_strvar','jhila_strvar','rajya_strvar']:
      exec(f"{i}.set('')") 
  #  dob.set_date(datetime.datetime.now().date())
#    birthdate.set_date(datetime.datetime.now().date())
#    admidate.set_date(datetime.datetime.now().date())
#    schoolleftdate.set_date(datetime.datetime.now().date())
#    leavingcertificateissuedate.set_date(datetime.datetime.now().date())
#    today = date.today()
   SEARCH.set("")
   #search.delete(0,END)
   #print("Today's date:", today)
   lcyn_Intvar.set(0) 
   varun_label = Label(text="",height=150,width=150)
   varun_label.place(relx=0.59,y=5,relheight=0.2,relwidth=0.1)
   varun_label.config(bg=lf_bg)
      
   register_num.focus()  
        
#======================================================================================================================================
def reset_form():
   global tree
   #tree.delete(*tree.get_children())
   reset_fields()
   SEARCH.set(" ")
   lcyn_Intvar.set(" ")
   lcyn_Intvar=OFF
   
#=======================================================================================================================================
def display_records():
   tree.delete(*tree.get_children())
   connection = pymysql.connect(**db_config)
   cursor = connection.cursor()
   #curr = cursor.execute('SELECT registernum, studentid,studentname,adharnumber,fathersname,surname,mothersname,mobileno,address,nationality,mothertongue,dharma,jat,potjat,Birthdate,birthplace,oldschool,Admidate,admistd,studyprogress,behaviour,Schoolleftdate,schoolleftreason,remark,Bankaccountno,Bankname,Bankbranch,Bankifsc,pustaknumber,lcyn,Leavingcertificateissuedate, taluka, jhila,rajya FROM newregister3')
   curr = cursor.execute('SELECT * FROM newregister3')
   data = cursor.fetchall()
   #print(data) 
   for records in data:
       tree.insert('', END, values=records)
##########doubleclick code stared#################

#        tree.bind("<Double-1>",OnDoubleClick)
# def OnDoubleClick(self):
#     global prevent
#     #getting focused item from treeview
#     current_item = tree.focus()
#     values = tree.item(current_item)
#     selection = values["values"]
#     registernum_strvar.set(selection[1]); studentid_strvar.set(selection[2])
#     studentname_strvar.set(selection[3]);adharnumber_strvar.set(selection[4])
#     fathersname_strvar.set(selection[5]);surname_strvar.set(selection[6])
#     mothersname_strvar.set(selection[7]); mobileno_strvar.set(selection[8])
#     address_strvar.set(selection[9]);  nationality_strvar.set(selection[10])
#     mothertongue_strvar.set(selection[11]);dharma_strvar.set(selection[12]);jat_strvar.set(selection[13])
#     potjat_strvar.set(selection[14])

#     date = datetime.date(int(selection[15][:4]), int(selection[15][5:7]), int(selection[15][8:]))

#     birthdate.set_date(date); birthplace_strvar.set(selection[16]); oldschool_strvar.set(selection[17])

#     date = datetime.date(int(selection[18][:4]), int(selection[18][5:7]), int(selection[18][8:]))
#     admidate.set_date(date)
 
#     admistd_strvar.set(selection[19])
#     studyprogress_strvar.set(selection[20])
        
#     behaviour_strvar.set(selection[21])
#     date = datetime.date(int(selection[22][:4]), int(selection[22][5:7]), int(selection[22][8:]))           
#     schoolleftdate.set_date(date)

#     schoolleftreason_strvar.set(selection[23])
#     remark_strvar.set(selection[24])
#     Bankaccountno_strvar.set(selection[25])
#     Bankname_strvar.set(selection[26])
#     Bankbranch_strvar.set(selection[27])
#     Bankifsc_strvar.set(selection[28]) 
#     pustaknumber_strvar.set(selection[29])
#     lcyn_Intvar.set(selection[30])
#     print(lcyn_Intvar)
        
#     date = datetime.date(int(selection[31][:4]), int(selection[31][5:7]), int(selection[31][8:]))
#     leavingcertificateissuedate.set_date(date)

#     prevent = True

#     imageid=str(selection[0]) 
    
#     connector.commit()
#     imagename='student'+imageid+".jpg"
    
#     print(imagename)
#         # Python program to explain cv2.imshow() method
        
#     image = Image.open(imagename)
#         #image.show()
#     photo = ImageTk.PhotoImage(image)
#     imgtext=Text(image=photo,height=150,width=150)
#     #varun_label = Label(image=photo,height=150,width=150)
#     #varun_label.place(relx=0.59,y=5,relheight=0.2,relwidth=0.1)
#     imgtext.place(relx=0.59,y=5,relheight=0.2,relwidth=0.1)
#     imgtext.destroy()
#        # photo
        
#     # Reading an image in default mode
#     image = cv2.imread(imagepath)

#     # Window name in which image is displayed
#     window_name = 'image'
#     if window_name:
#          cv2.waitKey(0)
#     else: 
#            print("no image")

#     # closing all open windows
#     cv2.destroyAllWindows()
   ##########################doubleclick code ended#################     

     
def addphoto():
     Imageid= connector.execute("select max(registerid) from newregister3").fetchone()
     print(Imageid)
     abc=str(Imageid)
     connector.commit()
     print(Imageid) 
     abc='student'+(abc)
     print(abc)
     display_records()
  #      Source file path
     source = 'filename.jpg'
     print(source)
  #      destination file path
     dest = abc + ".jpg" #'GeekforGeeks/newfile.txt'
     print(dest)
  #      Now rename the source path
  #      to destination path
  #      using os.rename() method
     os.rename(source,dest)

           
def add_record():
  global registernum_strvar,studentid_strvar,adharnumber_strvar,studentname_strvar,fathersname_strvar,surname_strvar,mothersname_strvar,mobileno_strvar,address_strvar,nationality_strvar,mothertongue_strvar,dharma_strvar,jat_strvar,potjat_strvar,birthdate,birthplace_strvar,oldschool_strvar,admidate,admistd_strvar,studyprogress_strvar,behaviour_strvar,schoolleftdate,schoolleftreason_strvar,remark_strvar,Bankaccountno_strvar,Bankname_strvar,Bankbranch_strvar,Bankifsc_strvar,pustaknumber_strvar,lcyn_Intvar,leavingcertificateissuedate,fullname,prevent,taluka_strvar,jhila_strvar,rajya_strvar
  global prevent
  global imagename,selection
  global registernum,mothersname,mobileno
  global studentid
  global mobileno

  registernum = registernum_strvar.get()  
  studentid =studentid_strvar.get()
  studentname=studentname_strvar.get() 
  adharnumber=adharnumber_strvar.get()
  fathersname=fathersname_strvar.get()
  surname=surname_strvar.get()
  mothersname=mothersname_strvar.get()
  mobileno=mobileno_strvar.get()
  address=address_strvar.get()
  nationality=nationality_strvar.get()
  mothertongue=mothertongue_strvar.get()
  dharma=dharma_strvar.get()
  jat=jat_strvar.get()
  potjat=potjat_strvar.get()
  Birthdate=birthdate.get()
  birthplace=birthplace_strvar.get()
  oldschool=oldschool_strvar.get()
  Admidate=admidate.get()
  admistd=admistd_strvar.get()
  studyprogress=studyprogress_strvar.get()
  behaviour=behaviour_strvar.get()
  Schoolleftdate=schoolleftdate.get()
  schoolleftreason=schoolleftreason_strvar.get()
  remark=remark_strvar.get()
  Bankaccountno=Bankaccountno_strvar.get()
  Bankname=Bankname_strvar.get()
  Bankbranch=Bankbranch_strvar.get()
  Bankifsc=Bankifsc_strvar.get()
  pustaknumber=pustaknumber_strvar.get()
  lcyn=lcyn_Intvar.get()
  leavingcertificateissuedate=leavingcertificateissuedate_strvar.get()
  fullname = studentname + " " + fathersname + " " + surname  
  taluka = taluka_strvar.get()
  jhila=jhila_strvar.get() 
  rajya=rajya_strvar.get() 
  fullname = studentname + " " + fathersname + " " + surname  
  connection = pymysql.connect(**db_config)
  conn = connection.cursor()
#   conn.execute("SELECT registernum FROM newregister3")
#   records_check1 = conn.fetchall()
  if registernum.isdigit() == False  or register_num == "" and mobileno.isdigit == False and studentid.isdigit == False: 
        mb.showerror("Message","Enter Digit in Register number,student id and Mobile number!!")
#   if records_check1 is not None:
#        mb.showwarning("Message","Record already exists")
  else:
    sql = 'INSERT INTO newregister3(registernum, studentid,studentname,adharnumber,fathersname,surname,mothersname,mobileno,address,nationality,mothertongue,dharma,jat,potjat,Birthdate,birthplace,oldschool,Admidate,admistd,studyprogress,behaviour,Schoolleftdate,schoolleftreason,remark,Bankaccountno,Bankname,Bankbranch,Bankifsc,pustaknumber,lcyn,leavingcertificateissuedate, taluka, jhila,rajya,fullname) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'#36  
    val = (registernum,studentid,studentname,adharnumber,fathersname,surname,mothersname,mobileno,address,nationality,mothertongue,dharma,jat,potjat,Birthdate,birthplace,oldschool,Admidate,admistd,studyprogress,behaviour,Schoolleftdate,schoolleftreason,remark,Bankaccountno,Bankname,Bankbranch,Bankifsc,pustaknumber,lcyn,leavingcertificateissuedate,taluka,jhila,rajya,fullname)
    conn.execute(sql,val)    
    connection.commit()
    mb.showinfo('Record added', f"Record of {registernum} was successfully added")
    display_records()  
    reset_fields()
    conn.execute("select max(registerid) from newregister3")
    Imageid=conn.fetchone()
    print(Imageid)
    abc=str(Imageid)
    print(abc)
    connection.commit()
    print(Imageid) 
 #   abc='student'+(abc)
    print(abc)
    display_records()
    #         Source file path
    source = 'filename.jpg'
    print(source)
    #          destination file path
    dest = "student" + abc + ".jpg" #'GeekforGeeks/newfile.txt'
    print(dest)
          #    Now rename the source path
          #    to destination path
          #    using os.rename() method
    os.rename(source,dest)
    #shutil.move(source,dest)
    print("file renamed")
    

def update():
#     #Database()
# sql = "UPDATE table SET telefonnummer = ? WHERE telefonnummer = ?"
  registernum = registernum_strvar.get()  
  studentid =studentid_strvar.get()
  studentname=studentname_strvar.get() 
  adharnumber=adharnumber_strvar.get()
  fathersname=fathersname_strvar.get()
  surname=surname_strvar.get()
  mothersname=mothersname_strvar.get()
  mobileno=mobileno_strvar.get()
  address=address_strvar.get()
  nationality=nationality_strvar.get()
  mothertongue=mothertongue_strvar.get()
  dharma=dharma_strvar.get()
  jat=jat_strvar.get()
  potjat=potjat_strvar.get()
  Birthdate=birthdate.get()
  birthplace=birthplace_strvar.get()
  oldschool=oldschool_strvar.get()
  Admidate=admidate.get()
  admistd=admistd_strvar.get()
  studyprogress=studyprogress_strvar.get()
  behaviour=behaviour_strvar.get()
  Schoolleftdate=schoolleftdate.get()
  schoolleftreason=schoolleftreason_strvar.get()
  remark=remark_strvar.get()
  Bankaccountno=Bankaccountno_strvar.get()
  Bankname=Bankname_strvar.get()
  Bankbranch=Bankbranch_strvar.get()
  Bankifsc=Bankifsc_strvar.get()
  pustaknumber=pustaknumber_strvar.get()
  lcyn=lcyn_Intvar.get()
  leavingcertificateissuedate=leavingcertificateissuedate_strvar.get()
  fullname = studentname + " " + fathersname + " " + surname  
  taluka = taluka_strvar.get()
  jhila=jhila_strvar.get() 
  rajya=rajya_strvar.get() 
  fullname = studentname + " " + fathersname + " " + surname  
  connection = pymysql.connect(**db_config)
  conn = connection.cursor()
  if registernum.isdigit() == False  or register_num == "" and mobileno.isdigit == False and studentid.isdigit == False: 
        mb.showerror("Message","Enter Digit in Register number,student id and Mobile number!!")
  else:
    # "UPDATE table SET telefonnummer = ? WHERE telefonnummer = ?"
    sql = 'UPDATE newregister3 SET studentid=%s,studentname=%s,adharnumber=%s,fathersname=%s,surname=%s,mothersname=%s,mobileno=%s,address=%s,nationality=%s,mothertongue=%s,dharma=%s,jat=%s,potjat=%s,Birthdate=%s,birthplace=%s,oldschool=%s,Admidate=%s,admistd=%s,studyprogress=%s,behaviour=%s,Schoolleftdate=%s,schoolleftreason=%s,remark=%s,Bankaccountno=%s,Bankname=%s,Bankbranch=%s,Bankifsc=%s,pustaknumber=%s,lcyn=%s,leavingcertificateissuedate=%s, taluka=%s, jhila=%s,rajya=%s,fullname=%s WHERE registernum=%s'#36  
    val = (studentid,studentname,adharnumber,fathersname,surname,mothersname,mobileno,address,nationality,mothertongue,dharma,jat,potjat,Birthdate,birthplace,oldschool,Admidate,admistd,studyprogress,behaviour,Schoolleftdate,schoolleftreason,remark,Bankaccountno,Bankname,Bankbranch,Bankifsc,pustaknumber,lcyn,leavingcertificateissuedate,taluka,jhila,rajya,fullname,registernum)
    conn.execute(sql,val)    
    connection.commit()
    mb.showinfo('Record Updated', f"Record of {registernum} was successfully updated")
    
    display_records()  
    conn.execute("select max(registerid) from newregister3")
    Imageid=conn.fetchone()
    print(Imageid)
    abc=str(Imageid)
    print(abc)
    connection.commit()
    print(Imageid) 
 #   abc='student'+(abc)
    print(abc)
    display_records()
    #         Source file path
    source = 'filename.jpg'
    print(source)
    #          destination file path
    dest = "student" + abc + ".jpg" #'GeekforGeeks/newfile.txt'
    print(dest)
          #    Now rename the source path
          #    to destination path
          #    using os.rename() method
    os.rename(source,dest)
    #shutil.move(source,dest)
    print("file renamed")


def validate():
    registernum_check = registernum_strvar.get()
    studentid_check = studentid_strvar.get()
    mobileno_check = mobileno_strvar.get()

    if registernum_check.isdigit() == False  or register_num == "" and mobileno_check.isdigit == False and studentid_check.isdigit == False: 
        mb.showerror("Message","Enter Digit!!")
    
def Insert():
        global Insert_id
        connection = pymysql.connect(**db_config)
    #create Cursor
        con = connection.cursor()
    #     connection = sqlite3.connect('school.db')
    # #create Cursor
    #     con = connection.cursor()
        
        record_id = register_num.get()
        
    #query the database
   
        con.execute("SELECT * FROM newregister3 WHERE registernum = " + record_id)
        
        records = con.fetchall()
        print(records)
        if records:
            msg = messagebox.askyesno("Message","Record already exists and add new one")
            reset_fields()
            register_num.destroy()
            register_num_destroy = Entry(main, width=10, textvariable=registernum_strvar,font=entryfont)
            register_num_destroy.place(x=180,y=20)
            register_num_destroy.focus()
        # if register_num_destroy.get() == "":
        #             messagebox.showinfo("Message","Enter Digit in the Register Number Field")
           
        #     messagebox.showwarning("Message","Record already exists")
        #     register_num.focus()          
            
 
      
def remove_record():
   if not tree.selection():
       mb.showerror('Error!', 'Please select an item from the database')
   else:
        result = tkMessageBox.askquestion('Confirm', 'Are you sure you want to delete this record?',
                                          icon="warning")
        if result == 'yes':
         connection = pymysql.connect(**db_config)
         con = connection.cursor()   
         current_item = tree.focus()
         values = tree.item(current_item)
         selection = values["values"]
         tree.delete(current_item)
         con.execute('DELETE FROM newregister3 WHERE registerid=%s' % selection[0])
        
         mb.showinfo('Done', 'The record you wanted deleted was successfully deleted.')
         connection.commit()
         display_records()
         reset_fields()

def view_record():
   global registernum_strvar,studentid_strvar,adharnumber_strvar,studentname_strvar,fathersname_strvar,surname_strvar,mothersname_strvar,mobileno_strvar,address_strvar,nationality_strvar,mothertongue_strvar,dharma_strvar,jat_strvar,potjat_strvar,birthdate,birthplace_strvar,oldschool_strvar,admidate,admistd_strvar,studyprogress_strvar,behaviour_strvar,schoolleftdate,schoolleftreason_strvar,remark_strvar,Bankaccountno_strvar,Bankname_strvar,Bankbranch_strvar,Bankifsc_strvar, pustaknumber_strvar,lcyn_Intvar,leavingcertificateissuedate_strvar,taluka_strvar,jhila_strvar,rajya_strvar
   global prevent,selection,filename
   if not tree.selection():
       mb.showerror('Error!', 'Please select a record to view')
   else:
        current_item = tree.focus()
        values = tree.item(current_item)
        selection = values["values"]
        registernum_strvar.set(selection[1]); studentid_strvar.set(selection[2])
        studentname_strvar.set(selection[3]);adharnumber_strvar.set(selection[4])
        fathersname_strvar.set(selection[5]);surname_strvar.set(selection[6])
        mothersname_strvar.set(selection[7]); mobileno_strvar.set(selection[8])
        address_strvar.set(selection[9]);  nationality_strvar.set(selection[10])
        mothertongue_strvar.set(selection[11]);dharma_strvar.set(selection[12]);jat_strvar.set(selection[13])
        potjat_strvar.set(selection[14])

        # date = datetime.date(int(selection[15][:4]), int(selection[15][5:7]), int(selection[15][8:]))

        birthdate_strvar.set(selection[15]); 
        birthplace_strvar.set(selection[16]); oldschool_strvar.set(selection[17])

        #date = datetime.date(int(selection[18][:4]), int(selection[18][5:7]), int(selection[18][8:]))
        admidate_strvar.set(selection[18])
    
        admistd_strvar.set(selection[19])
        studyprogress_strvar.set(selection[20])

        behaviour_strvar.set(selection[21])
        #date = datetime.date(int(selection[22][:4]), int(selection[22][5:7]), int(selection[22][8:]))           
        schoolleftdate_strvar.set(selection[22])

        schoolleftreason_strvar.set(selection[23])
        remark_strvar.set(selection[24])
        Bankaccountno_strvar.set(selection[25])
        Bankname_strvar.set(selection[26])
        Bankbranch_strvar.set(selection[27])
        Bankifsc_strvar.set(selection[28]) 
        pustaknumber_strvar.set(selection[29])
        lcyn_Intvar.set(selection[30])
        print(lcyn_Intvar)

        #date = datetime.date(int(selection[31][:4]), int(selection[31][5:7]), int(selection[31][8:]))
        leavingcertificateissuedate_strvar.set(selection[31])

        prevent = True

        imageid=str(selection[0])

        connector.commit()
        
        imagename='student('+imageid+ ',)' + ".jpg"

        print(imagename)
            # Python program to explain cv2.imshow() method

        image = Image.open(imagename)
            #image.show()
        photo = ImageTk.PhotoImage(image)
        varun_label=Label(image=photo,height=150,width=150)
        #varun_label = Label(image=photo,height=150,width=150)
        #varun_label.place(relx=0.59,y=5,relheight=0.2,relwidth=0.1)
        varun_label.place(relx=0.59,y=5,relheight=0.2,relwidth=0.1)
        #imgtext.destroy()
           # photo

        # Reading an image in default mode
        image = cv2.imread(imagepath)

        # Window name in which image is displayed
        window_name = 'image'
        if window_name:
             cv2.waitKey(0)
        else: 
               print("no image")

        # closing all open windows
        cv2.destroyAllWindows()
   ##########################doubleclick code ended#################     

# def Update():
#     #Database()
#   connector=sqlite3.connect('school.db')
#   global registernum_strvar,studentid_strvar,adharnumber_strvar,studentname_strvar,fathersname_strvar,surname_strvar,mothersname_strvar,mobileno_strvar,address_strvar,nationality_strvar,mothertongue_strvar,dharma_strvar,jat_strvar,potjat_strvar,birthdate,birthplace_strvar,oldschool_strvar,admidate,admistd_strvar,studyprogress_strvar,behaviour_strvar,schoolleftdate,schoolleftreason_strvar,remark_strvar,Bankaccountno_strvar,Bankname_strvar,Bankbranch_strvar,Bankifsc_strvar,pustaknumber_strvar,lcyn_Intvar,leavingcertificateissuedate 
#   registernum =registernum_strvar.get()  
#   studentid =studentid_strvar.get()
#   studentname=studentname_strvar.get()
#   adharnumber=adharnumber_strvar.get()
#   fathersname=fathersname_strvar.get()
#   surname=surname_strvar.get()
#   mothersname=mothersname_strvar.get()
#   mobileno=mobileno_strvar.get()
#   address=address_strvar.get()
#   nationality=nationality_strvar.get()
#   mothertongue=mothertongue_strvar.get()
#   dharma=dharma_strvar.get()
#   jat=jat_strvar.get()
#   potjat=potjat_strvar.get()

#   Birthdate=birthdate.get_date()
#   birthplace=birthplace_strvar.get()
#   oldschool=oldschool_strvar.get()
#   Admidate=admidate.get_date()
#   admistd=admistd_strvar.get()
#   studyprogress=studyprogress_strvar.get()
#   behaviour=behaviour_strvar.get()
#   Schoolleftdate=schoolleftdate.get_date()
#   schoolleftreason=schoolleftreason_strvar.get()
#   remark=remark_strvar.get()
#   Bankaccountno=Bankaccountno_strvar.get()
#   Bankname=Bankname_strvar.get()
#   Bankbranch=Bankbranch_strvar.get()
#   Bankifsc=Bankifsc_strvar.get()
#   pustaknumber=pustaknumber_strvar.get()
#   lcyn=lcyn_Intvar.get()
#   Leavingcertificateissuedate=leavingcertificateissuedate.get_date()

#   current_item = tree.focus()
#   values = tree.item(current_item)
#   selection = values["values"]   
#         # #update query                                             
#   connector.execute('UPDATE newregister3 SET registernum=?,studentid=?,studentname=?,adharnumber=?,fathersname=?,surname=?,mothersname=?,mobileno=?,address=?,nationality=?,mothertongue=?,dharma=?,jat=?,potjat=?,Birthdate=?,birthplace=?,oldschool=?,Admidate=?,admistd=?,studyprogress=?,behaviour=?,Schoolleftdate=?,schoolleftreason=?,remark=?,Bankaccountno=?,Bankname=?,Bankbranch=?,Bankifsc=?,pustaknumber=?,lcyn=?,Leavingcertificateissuedate=? WHERE registerid=? ',(registernum, studentid,studentname,adharnumber,fathersname,surname,mothersname,mobileno,address,nationality,mothertongue,dharma,jat,potjat,Birthdate,birthplace,oldschool,Admidate,admistd,studyprogress,behaviour,Schoolleftdate,schoolleftreason,remark,Bankaccountno,Bankname,Bankbranch,Bankifsc,pustaknumber,lcyn, Leavingcertificateissuedate, selection[0]))
#   connector.commit()
#   mb.showinfo("Message","Updated successfully")
#   #refresh table data
#   display_records()
#   studentname_strvar.get()+fathersname_strvar.get()+surname_strvar.get()      
#  # reset_fields()
#   prevent=False
#   prevent = False             
 

#   Imageid= connector.execute("select max(registerid) from newregister3").fetchone()
#   print(Imageid)
#   abc=str(Imageid)
#   connector.commit()
#   print(Imageid) 
#   abc='student'+(abc)
#   print(abc)
#   display_records()
#   # Source file path
#   source = 'filename.jpg'
#   print(source)
#   # destination file path
#   dest = abc + ".jpg" #'GeekforGeeks/newfile.txt'
#   print(dest)
#   # Now rename the source path
#   # to destination path
#   # using os.rename() method
#   os.rename(source,dest)
#   connector.close()
def SearchRecord():
    #open database
    connector=pymysql.connect(**db_config)
    conn = connector.cursor()
    #checking search text is empty or not
    if SEARCH.get() != "":
        #clearing current display data
        tree.delete(*tree.get_children())
        #select query with where clause
#         mysql_conn.query_db(
#     "select * from table_one where col_name like %s order by id asc limit 5",
#      ("%{}%".format(param),))
        cursor = conn.execute("select * from newregister3 where studentname like %s order by registernum ",("%{}%".format(SEARCH.get()),))
        # cursor=conn.execute("SELECT * FROM newregister3 WHERE studentname LIKE ?", ((SEARCH.get()),))
        #fetch all matching records
        fetch = conn.fetchall()
        #loop for displaying all records into GUI
        for data in fetch:
            tree.insert('', 'end', values=(data))
        conn.close()
        
        connector.close()
         
  
def SearchRecord1():
    #open database
    connection = pymysql.connect(**db_config)
    #connector=sqlite3.connect('school.db')
    #checking search text is empty or not
    if SEARCH.get() != "":
        #clearing current display data
        tree.delete(*tree.get_children())
        #select query with where clause
        cursor=connector.execute("SELECT * FROM newregister3 WHERE studentname LIKE ?", ('%' + str(SEARCH.get()) + '%',))
        #fetch all matching records
        fetch = cursor.fetchall()
        #loop for displaying all records into GUI
        for data in fetch:
            tree.insert('', 'end', values=(data))
        cursor.close()
        
        connector.close()
         

def clear():
        registernum_strvar.delete(0,END)
        studentid_strvar.delete(0,END)
        studentname_strvar.delete(0,END)
        fathersname_strvar.delete(0,END)
        surname_strvar.delete(0,END)
        mothersname_strvar.delete(0,END)
        mobileno_strvar.delete(0,END)
        address_strvar.delete(0,END)
        nationality_strvar.delete(0,END)
        mothertongue_strvar.delete(0,END)
        dharma_strvar.delete(0,END)
        jat_strvar.delete(0,END)
        potjat_strvar.delete(0,END)
        birthdate.delete(0,END)
        birthplace_strvar.delete(0,END)
        oldschool_strvar.delete(0,END)
        admidate.delete(0,END)
        admistd_strvar.delete(0,END)
        studyprogress_strvar.delete(0,END)
        behaviour_strvar.delete(0,END)
        schoolleftdate.delete(0,END)
        schoolleftreason_strvar.delete(0,END)
        remark_strvar.delete(0,END)
        Bankaccountno_strvar.delete(0,END)
        Bankname_strvar.delete(0,END)
        Bankbranch_strvar.delete(0,END)
        Bankifsc_strvar.delete(0,END)
        pustaknumber_strvar.delete(0,END)
        lcyn_Intvar.delete(0,END)
        leavingcertificateissuedate.delete(0,END)    
        search.delete(0,END)
      #  photo.delete(0,END)
        varun_label.delete(0,END)
        varun_label.set(" ")
        SEARCH.set("")
#####################################################################################################################################

######################################################################################################################################
def photo_record():
        global photoid 
# 1.creating a video object
        
        video = cv2.VideoCapture(0) 
        #width,height = 100,100
        width ,height=0.6,1
        video.set(cv2.CAP_PROP_FRAME_WIDTH,width) 
        video.set(cv2.CAP_PROP_FRAME_HEIGHT,height)
        
# 2. Variable
        a = 0
# 3. While loop
        while True:
               a = a + 1
# 4.Create a frame object

               check, frame1 = video.read()
               print(check) #prints true as long as the webcam is running
               print(frame1) #prints matrix values of each framecd 
               check, frame1 = video.read()
# 5.show the frame!
              
               cv2.imshow("Capturing",frame1)
               frame1.resize(150,150)
                  
               cv2. width,height= 0.6,1
# 6.for playing 
               key = cv2.waitKey(1)
               if key == ord('q') or key == ord('Q'):
                  connection=pymysql.connect(**db_config)
                  conn = connection.cursor()
                  conn.execute("select max(registerid) from newregister3")
                  Imageid= conn.fetchone()
                  print(Imageid)
                  abc=str(Imageid)
                  connection.commit()
                  print(Imageid) 
 #                    abc='student'+(abc)
                  print(abc)
                  display_records()
                  
                  break
# 7. image saving
        retrun_value, image = video.read()
        cv2.imwrite("filename.jpg",image)          
        #frame1=cv2.imshow("filename.jpg",frame1)

# 8. shutdown the camera
        video.release()
        cv2.destroyAllWindows 


engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
    # print(voices[1].id)
engine.setProperty('voice', voices[0].id)
r = sr.Recognizer()

def listen(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if student_name.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                student_name.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")

    except Exception as e:
        # print(e)    
        print("Say that again please...") 

def listenfathers_name(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if fathers_name.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                fathers_name.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listensurname(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if surname.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                surname.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listenmothersname(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if mothers_name.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                mothers_name.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listenaddress(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if address.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                address.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listenstate(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if State.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                State.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listenmothertongue(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if mothertongue.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                mothertongue.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listendharma(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if dharma.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                dharma.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listenjat(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if jat.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                jat.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listenpotjat(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if potjat.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                potjat.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listenbirthplace(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if birthplace.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                birthplace.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listenoldschool(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if oldschool.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                oldschool.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listenreason(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if schoolleft_reason.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                schoolleft_reason.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listenbankname(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if bankname.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                bankname.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listenbankbranch(*args):
        
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=3)

    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if bankbranch.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                bankbranch.insert(0,f"{query}\n")
            
            # elif Input_6.get() == '':
            #     Input_6.insert(0,f"{query}\n")
            # elif Input_7.get() == '':
            #     Input_7.insert(0,f"{query}\n")

            else:
                messagebox.showerror("Message","Say that again please!")
        

    except Exception as e:
        # print(e)    
        print("Say that again please...") 

def listenfunction():
    student_name.bind('<FocusIn>',lambda event: listen())
    fathers_name.bind('<FocusIn>',lambda event: listenfathers_name())
    surname.bind('<FocusIn>',lambda event: listensurname())
    mothers_name.bind('<FocusIn>',lambda event: listenmothersname())
    address.bind('<FocusIn>',lambda event: listenaddress())
    State.bind('<FocusIn>',lambda event: listenstate())
    mothertongue.bind('<FocusIn>',lambda event: listenmothertongue())
    dharma.bind('<FocusIn>',lambda event: listendharma())
    jat.bind('<FocusIn>',lambda event: listenjat())
    potjat.bind('<FocusIn>',lambda event: listenpotjat())
    birthplace.bind('<FocusIn>',lambda event: listenbirthplace())
    oldschool.bind('<FocusIn>',lambda event: listenoldschool())
    schoolleft_reason.bind('<FocusIn>',lambda event: listenreason())
    bankname.bind('<FocusIn>',lambda event: listenbankname())
    bankbranch.bind('<FocusIn>',lambda event: listenbankbranch())
#=========================================================================================================
def ExporttoExcel():

    import pandas as sql

   #  import excelregister
     # import the modules

# connect the mysql with the python
    con=pymysql.connect(**db_config)

# read the data
    df=sql.read_sql('select * from newregister3',con)

# print the data
    #print(df)

# export the data into the excel sheet
    df.to_excel('D:\\reports\\student.xlsx')
    # excelregister
    messagebox.showinfo("Message","Excel File Created")

def ExporttoExcel1():
    filePath = "d:/reports/StudentExcelData.xlsx"

# database connection
    conn = sqlite3.connect("school.db")

# writer for write the data into excel file
    writer = pd.ExcelWriter(filePath, engine='xlsxwriter')

# create a data frame
    df = pd.read_sql("SELECT * FROM newregister3", conn)

    sheet_name = 'newregister3'

    # sql query variable
    SQL = "select * from" + " " + sheet_name
    #print(SQL)

    # load data from sqlite into dataframe
    dft = pd.read_sql(SQL, conn)

    # load data into excel file
    dft.to_excel(writer, sheet_name=sheet_name, index=False)
    print('Excel Sheet has been created successfully!')

    writer.close()    
    mb.showinfo('Done', 'The Excel file is successfully created at d:/reports/StudentExcelData.xlsx.')
def checkemptyregister_num():
    registernum_check = registernum_strvar.get()
    connection = pymysql.connect(**db_config)
    conn = connection.cursor()
    conn.execute("SELECT * FROM newregister3 where registernum = %s",(register_num.get()))
    records = conn.fetchall()
    
    if registernum_check.isdigit() == False  or register_num == "": 
            mb.showerror("Message","Enter Digit in the Register Number Field!!")
            register_num.focus()
    if records:
         mb.showinfo("Message","Record already exists")
         register_num.focus()
def checkemptymobile_num():
    
    mobileno_check = mobileno_strvar.get()  
    
    if mobileno_check.isdigit == False :
            mb.showerror("Message","Enter Digit in the Mobile Number Field!!")
            mobile_num.focus() 
    
    
        
        
        # mb.showerror("Message","Enter Digit!!")    
def checkemptystudent_id():
    studentid_check = studentid_strvar.get()
    
    if studentid_check.isdigit == False: 
            mb.showerror("Message","Enter Digit in the Register Number Field!!")
            student_id.focus()
def go_to_next_entry(event, entry_list, this_index):
    next_index = (this_index + 1) % len(entry_list)
    entry_list[next_index].focus_set()
    global Insert_id
        # global register_num_destroy
    connection = pymysql.connect(**db_config)
    #create Cursor
    con = connection.cursor()
        
    record_id = register_num.get()
        
    #query the database
    con.execute("SELECT * FROM newregister3 WHERE registernum = " + record_id)
        
    records = con.fetchall()

    if records:
         mb.showwarning("Message","Record already exists!!")

         


#Form Design
main = Tk()
main.title('School Management System')
main.geometry('1366x768')
main.config(bg="DarkSeaGreen3")
#main.resizable(0, 0)
lf_bg = "DarkSeaGreen3" # bg color for the main
cf_bg = 'PaleGreen' # bg color for the main

########################################### Voice Recognition #################################################################

############################################ Creating the StringVar or IntVar variables##############################################
#today_date = datetime.datetime.now().date()
registernum_strvar=StringVar()
studentid_strvar=StringVar()
adharnumber_strvar=StringVar()
studentname_strvar=StringVar()
fathersname_strvar=StringVar()
surname_strvar =StringVar()
mothersname_strvar =StringVar()
mobileno_strvar =StringVar()
address_strvar =StringVar()
nationality_strvar =StringVar()
mothertongue_strvar =StringVar()
dharma_strvar =StringVar()
jat_strvar =StringVar()
potjat_strvar =StringVar()
birthdate_strvar=StringVar()   ##############date entery##################
birthplace_strvar=StringVar()
oldschool_strvar=StringVar()
admidate_strvar=StringVar()     ##############date entery##################
admistd_strvar=StringVar()
studyprogress_strvar =StringVar()
behaviour_strvar =StringVar()
schoolleftdate_strvar=StringVar()  ##############date entery##################
schoolleftreason_strvar=StringVar()
remark_strvar =StringVar()
leavingcertificateissuedate_strvar=StringVar()
Bankaccountno_strvar=StringVar()
Bankname_strvar =StringVar()
Bankbranch_strvar=StringVar()
Bankifsc_strvar =StringVar()
pustaknumber_strvar=StringVar()
lcyn_Intvar=IntVar()
fullname = StringVar()
imagepath = StringVar()
imagename =  StringVar()
taluka_strvar=StringVar()
jhila_strvar=StringVar()
rajya_strvar=StringVar()
varun_label=DoubleVar
#varun_label = StringVar()
global Insert_id
Insert_id = StringVar()
global register_num
preventry=TRUE
Tk.Checkbutton=StringVar()
SEARCH=StringVar()
#lcyn_Intvar.set(1)
right_frame = Frame(main, bg="Gray35")
right_frame.place(relx=0.69, y=14, relheight=1, relwidth=0.3)

#frame = Frame(main, width=600, height=400)


lbl_txtsearch = Label(main, text="Enter name to Search", font=('verdana', 10),bg=lf_bg).place(x=780,y=210)
    #creating search entry

    #creating search entry
search = Entry(main, textvariable=SEARCH, font=('verdana', 10), width=20).place(x=775,y=235)
btn_search = Button(main, text="Search", command=SearchRecord,width=8).place(x=790,y=260)
btn_viewall = Button(main,text="View All",command=display_records,width=8)
btn_viewall.place(x=860,y=260)
btn_update = Button(main,text="Update",command=update,width=8)
btn_update.place(x=810,y=300)


# Placing components in the left frame

Label(main, text="जनरल रजिस्टर क्र.", font=labelfont, bg=lf_bg).place(x=27,y=20)
register_num = Entry(main, width=10, textvariable=registernum_strvar,font=entryfont)
register_num.place(x=180,y=20)
register_num.bind("<Tab>",lambda event: checkemptyregister_num())

# register_num.bind('<Return>',lambda event: checkempty())
#register_num.bind('<Return>',lambda event: secondentry())
# main.bind('<Return>',lambda event: validate())

# register_num.bind('<Tab>')


Label(main, text="स्टुडंट आय.डी.", font=labelfont, bg=lf_bg).place(x=27,y=60)
student_id = Entry(main, width=10, textvariable=studentid_strvar,font=entryfont)
student_id.place(x=180,y=60)
student_id.bind("<FocusOut>",lambda event: checkemptystudent_id())
#student_id.bind('<Tab>',lambda event: validate())
Label(main,text="0-9").place(x=280,y=60)
Label(main, text="यु.आय.डी.", font=labelfont, bg=lf_bg).place(x=27,y=100)
adhar_num = Entry(main, width=10, textvariable=adharnumber_strvar,font=entryfont)
adhar_num.place(x=180,y=100)
Label(main,text="नाव",font=labelfont,bg=lf_bg).place(x=27,y=140)
student_name = Entry(main,width=10,textvariable=studentname_strvar,font=entryfont)
student_name.place(x=180,y=140)

Label(main, text="वडिलांचे नाव", font=labelfont, bg=lf_bg).place(x=27,y=180)
fathers_name = Entry(main, width=10,textvariable=fathersname_strvar,font=entryfont)
fathers_name.place(x=180,y=180)


Label(main,text="आडनाव",font=labelfont,bg=lf_bg).place(x=27,y=220)
surname = Entry(main, width=10, textvariable=surname_strvar,font=entryfont)
surname.place(x=180,y=220)

Label(main,text="आईचे नाव",font=labelfont,bg=lf_bg).place(x=27,y=260)
mothers_name = Entry(main,width=10,textvariable=mothersname_strvar,font=entryfont)
mothers_name.place(x=180,y=260)

Label(main,text=" जन्मतारीख",font=labelfont,bg=lf_bg).place(x=17,y=300)
birthdate=Entry(main, width=10,textvariable=birthdate_strvar,font=entryfont)
#birthdate.pack(padx=150,pady=150)
birthdate.place(x=180,y=300)

Label(main,text="जन्मस्थळ",font=labelfont,bg=lf_bg).place(x=25,y=340)
birthplace = Entry(main,width=10,textvariable=birthplace_strvar,font=entryfont)
birthplace.place(x=180,y=340)
#birthplace.insert(0,"Hello")
Label(main,text="तालुका",font=labelfont,bg=lf_bg).place(x=25,y=390)
taluka = Entry(main,width=10,textvariable=taluka_strvar,font=entryfont)
taluka.place(x=180,y=390)
Label(main,text="जिल्हा",font=labelfont,bg=lf_bg).place(x=25,y=430)
jhila = Entry(main,width=10,textvariable=jhila_strvar,font=entryfont)
jhila.place(x=180,y=430)
Label(main,text="राज्य",font=labelfont,bg=lf_bg).place(x=25,y=470)
rajya = Entry(main,width=10,textvariable=rajya_strvar,font=entryfont)
rajya.place(x=180,y=470)


Label(main,text="राष्ट्रीयत्व",font=labelfont,bg=lf_bg).place(x=27,y=510)
State = Entry(main,width=10,textvariable=nationality_strvar,font=entryfont)
State.place(x=180,y=510)

Label(main,text="मातृभाषा",font=labelfont,bg=lf_bg).place(x=27,y=550)
mothertongue = Entry(main,width=10,textvariable=mothertongue_strvar,font=entryfont)
mothertongue.place(x=180,y=550)


Label(main,text="धर्म",font=labelfont,bg=lf_bg).place(x=27,y=590)
dharma = Entry(main,width=10,textvariable=dharma_strvar,font=entryfont)
dharma.place(x=180,y=590)

Label(main,text="जात",font=labelfont,bg=lf_bg).place(x=320,y=20)
jat = Entry(main,width=10,textvariable=jat_strvar,font=entryfont)
jat.place(x=530,y=20)

Label(main,text="पोट जात",font=labelfont,bg=lf_bg).place(x=320,y=60)
potjat = Entry(main,width=10,textvariable=potjat_strvar,font=entryfont)
potjat.place(x=530,y=60)


Label(main,text="मोबाईल नंबर",font=labelfont,bg=lf_bg).place(x=320,y=100)
mobile_num = Entry(main,width=10,textvariable=mobileno_strvar,font=entryfont)
mobile_num.place(x=530,y=100)
#mobile_num.bind('<Tab>',lambda event: validate())
Label(main,text="पत्ता",font=labelfont,bg=lf_bg).place(x=320,y=140)
address = Entry(main,width=10,textvariable=address_strvar,font=entryfont)
address.place(x=530,y=140)

Label(main,text="या पूर्वीची शाळा व इयत्ता",font=labelfont,bg=lf_bg).place(x=320,y=180)
oldschool = Entry(main,width=10,textvariable=oldschool_strvar,font=entryfont)
oldschool.place(x=530,y=180)

Label(main,text="प्रवेश दिनांक",font=labelfont,bg=lf_bg).place(x=320,y=220)
admidate=Entry(main,width=10,textvariable=admidate_strvar,font=entryfont)
admidate.place(x=530,y=220)
Label(main,text=" प्रवेश इयत्ता",font=labelfont,bg=lf_bg).place(x=315,y=260)
admistd = Entry(main,width=10,textvariable=admistd_strvar,font=entryfont)
admistd.place(x=530,y=260)

Label(main,text="अभ्यासातील प्रगती",font=labelfont,bg=lf_bg).place(x=320,y=300)
study_progress = Entry(main,width=10,textvariable=studyprogress_strvar,font=entryfont)
study_progress.place(x=530,y=300)
Label(main,text="वर्तणूक",font=labelfont,bg=lf_bg).place(x=320,y=340)
behaviour = Entry(main,textvariable=behaviour_strvar,font=entryfont,width=10)
behaviour.place(x=530,y=340)


Label(main,text="शाळा सोडल्याचे दिनांक ",font=labelfont,bg=lf_bg).place(x=320,y=380)
schoolleftdate=Entry(main, width=10,textvariable=schoolleftdate_strvar,font=entryfont)
schoolleftdate.place(x=530,y=380)
Label(main,text="शाळा सोडल्याचे कारण ",font=labelfont,bg=lf_bg).place(x=320,y=420)
schoolleft_reason = Entry(main,textvariable=schoolleftreason_strvar,font=entryfont,width=10)
schoolleft_reason.place(x=530,y=420)
Label(main,text="शेरा ",font=labelfont,bg=lf_bg).place(x=320,y=460)
remark = Entry(main,textvariable=remark_strvar,font=entryfont,width=10)
remark.place(x=530,y=460)


Label(main,text="शाळा सोडल्याचा दाखला ",font=labelfont,bg=lf_bg).place(x=320,y=500)
lcyn = Checkbutton(main, variable=lcyn_Intvar).place(x=530,y=500)

leavingcertificateissuedate=Entry(main,font=entryfont,textvariable=leavingcertificateissuedate_strvar,width=10)
leavingcertificateissuedate.place(x=570,y=500)

Label(main,text="पुस्तक नंबर",font=labelfont,bg=lf_bg).place(x=320,y=540)
pustaknumber = Entry(main,textvariable=pustaknumber_strvar,font=entryfont,width=10)
pustaknumber.place(x=530,y=540)

Label(main,text="बँकअकाऊंट नंबर",font=labelfont,bg=lf_bg).place(x=320,y=580)
bankaccount_no = Entry(main,textvariable=Bankaccountno_strvar,font=entryfont)
bankaccount_no.place(x=530,y=580)

Label(main,text="बँकेचे नांव",font=labelfont,bg=lf_bg).place(x=660,y=360)
bankname = Entry(main,textvariable=Bankname_strvar,font=entryfont)
bankname.place(x=755,y=360)

Label(main,text="बँकशाखा",font=labelfont,bg=lf_bg).place(x=660,y=400)
bankbranch = Entry(main,textvariable=Bankbranch_strvar,font=entryfont)
bankbranch.place(x=755,y=400)


Label(main,text="बँकआय एफ \n एस सी कोड",font=labelfont,bg=lf_bg).place(x=640,y=440)
ifsc_code = Entry(main,textvariable=Bankifsc_strvar,font=entryfont)
ifsc_code.place(x=755,y=440)






# main.bind("<Return>",lambda event: checkempty())
# main.bind("<Return>",lambda event: checkemptymobile_num())




submit_button=Button(main, text='Submit', font=labelfont,command=add_record, width=10).place(x=15,y=650) #relx=0.013, rely=0.90
# submit_button=Button(main, text='Submit', font=labelfont,command=add_record, width=10).place(x=15,y=650) #relx=0.013, rely=0.90
view_button=Button(main, text='View Record', font=labelfont, command=view_record, width=10).place(x=150,y=650)

clear_button=Button(main, text='Clear', font=labelfont, command=reset_fields, width=10).place(x=285,y=650)
# delete_button=Button(main, text='Delete', font=labelfont, command=remove_record, width=10).place(x=555,y=650)
delete_button=Button(main, text='Delete', font=labelfont, command=remove_record, width=10).place(x=555,y=650)
report_button=Button(main, text='Excel', font=labelfont, command=ExporttoExcel, width=10).place(x=690,y=650)

exit_button=Button(main, text='Exit', font=labelfont, command=main.destroy, width=10).place(x=815,y=650)
Voice_button=Button(main, text='Voice form', font=labelfont, command=listenfunction, width=10).place(x=420,y=650)
webcamera_button=Button(main,text='takephoto',font=labelfont,command=photo_record, width=10).place(relx=0.59,y=150)
# Placing components in the right frame

Label(right_frame, text='Register Records', font=headlabelfont, bg='DarkGreen', fg='LightCyan').pack(side=TOP, fill=X)
tree = ttk.Treeview(right_frame, height=100, selectmode=BROWSE,
                   columns=('registerid','registernum', 'studentid','studentname','aadharnumber'))
X_scroller = Scrollbar(tree, orient=HORIZONTAL, command=tree.xview)
Y_scroller = Scrollbar(tree, orient=VERTICAL, command=tree.yview)
X_scroller.pack(side=BOTTOM, fill=X)
Y_scroller.pack(side=RIGHT, fill=Y)
tree.config(yscrollcommand=Y_scroller.set, xscrollcommand=X_scroller.set)
tree.heading('registerid', text='Register ID', anchor=CENTER)
tree.heading('registernum', text='Register Num', anchor=CENTER)
tree.heading('studentid', text='Student id', anchor=CENTER)
tree.heading('studentname', text='Student name', anchor=CENTER)
tree.heading('aadharnumber', text='Aadharnumber', anchor=CENTER)
tree.column('#0', width=0, stretch=NO, minwidth=0)
tree.column('#1', width=40, stretch=NO,minwidth=0)
tree.column('#2', width=80, stretch=NO,minwidth=0)
tree.column('#3', width=120, stretch=NO,minwidth=0)
tree.column('#4', width=120, stretch=NO,minwidth=0)
tree.place(y=30, relwidth=1, relheight=0.9, relx=0)
display_records()


entries = [child for child in main.winfo_children() if isinstance(child, Entry)]
for idx, entry in enumerate(entries):
    entry.bind('<Return>', lambda e, idx=idx: go_to_next_entry(e, entries, idx))
# Finalizing the GUI window
main.update()
main.mainloop()