#====================All the Library Files===========================================================================================================
from tkinter import *   #support the label and entry input
import tkinter.messagebox as mb   #support  the messagebox 
import tkinter.ttk as ttk   #support the treeview and ttk
import sqlite3  #support sqlite database
import tkinter.messagebox as tkMessageBox
import pymysql
from tkinter import messagebox #support  the messagebox 
main = Tk()
main.title('ST Management System')
main.geometry('1366x768') 
main.config(bg="DarkSeaGreen3")
#==================================================================================================================================
# Creating the universal font variables
headlabelfont = ("Noto Sans CJK TC", 15, 'bold')
labelfont = ('Helvetica', 14)
entryfont = ('Helvetica', 12)
#connector=sqlite3.connect('standard.db')
db_config = {
    "host": "localhost",
    "user": "pc1",
    "password": "1234",
    "database": "standard",
}
connection = pymysql.connect(**db_config)
conn = connection.cursor()

#cursor = connector.cursor()
conn.execute(
"CREATE TABLE IF NOT EXISTS STANDARDTABLE (STANDARDID INTEGER PRIMARY KEY NOT NULL,STANDARDNAME TEXT , MAXSTUDCOUNT TEXT)"
)

prevent = False
#===================================================================================================================================
# Creating the functions
def reset_fields():
   global standardname_strvar, maxstudcount_strvar
   for i in ['standardname_strvar', 'maxstudcount_strvar']:
       exec(f"{i}.set('')")
       SEARCH.set("")
#=====================================================================================================================================   
def reset_form():
   global tree
   tree.delete(*tree.get_children())
   reset_fields()
#===================================================================================================================================
def display_records():
   global prevent
   tree.delete(*tree.get_children())
   connection = pymysql.connect(**db_config)
   conn =connection.cursor()
   conn.execute('SELECT standardname,maxstudcount FROM STANDARDTABLE')
   data = conn.fetchall()
   for records in data:
       tree.insert('', END, values=records)
##########doubleclick code stared#################

       tree.bind("<Double-1>",OnDoubleClick)
def OnDoubleClick(self):
    global prevent
#    getting focused item from treeview
    current_item = tree.focus()
    values = tree.item(current_item)
    selection = values["values"]
    standardname_strvar.set(selection[1]); maxstudcount_strvar.set(selection[2])
    prevent = True 

##########################doubleclick code ended#################
#====================================================================================================================================  
def add_record():
   global standardname_strvar, maxstudcount_strvar
   global prevent
   standardname=standardname_strvar.get()

   maxstudcount =   maxstudcount_strvar.get()
   connection = pymysql.connect(**db_config)
   conn=connection.cursor()
       
#    if not standardname or not maxstudcount :
#            mb.showerror('Error!', "Please fill all the missing fields!!")
#    else:
#           if prevent == False :   
#            connector=sqlite3.connect('standard.db')
#            #cursor = connector.cursor()

   sql='INSERT INTO STANDARDTABLE (STANDARDNAME, MAXSTUDCOUNT) VALUES (%s,%s)'
   val=(standardname, maxstudcount)
   conn.execute(sql,val)
           
   connection.commit()
   display_records()
   connection.close()
#            
    #      connector.commit()
   messagebox.showinfo("Message","Saved Sucessfully")
   display_records()
   reset_fields()
        #   else:
        #      connector=sqlite3.connect('standard.db')
    
        #      current_item = tree.focus()
        #      values = tree.item(current_item)
        #      selection = values["values"] 
    
        #      connector.execute('UPDATE   STANDARDTABLE SET  standardname=?,maxstudcount=? WHERE STANDARDID=? ',(standardname,maxstudcount, selection[0]))
        #      connector.commit()
       
        #      mb.showinfo("Message","Updated successfully")
  
        #      display_records()       
        #      reset_fields()
        # #refresh table data
             
        #      prevent = False
#========================================================================================================================================
   
def remove_record():
   if not tree.selection():
       mb.showerror('Error!', 'Please select an item from the database')
   else:
        result = tkMessageBox.askquestion('Confirm', 'Are you sure you want to delete this record?',
                                          icon="warning")
        if result == 'yes':
          connection = pymysql.connect(**db_config)  
          conn = connection.cursor()
         
          current_item = tree.focus()
          values = tree.item(current_item)
          selection = values["values"]
          tree.delete(current_item)
          conn.execute('DELETE FROM STANDARDTABLE WHERE STANDARDNAME=%s' % selection[0])
            #connector.commit()
          mb.showinfo('Done', 'The record you wanted deleted was successfully deleted.')

       
          connection.commit()
      #=====================================================================================================================================
def view_record():
   global standardname_strvar, maxstudcount_strvar
   global prevent
   connection = pymysql.connect(**db_config)  
   if not tree.selection():
       mb.showerror('Error!', 'Please select a record to view')
   else:
        current_item = tree.focus()
        values = tree.item(current_item)
        selection = values["values"]
        standardname_strvar.set(selection[0]); maxstudcount_strvar.set(selection[1])
        prevent = True
#======================================================================================================================================
def clear():
        standardname_strvar.delete(0,END)
        maxstudcount_strvar.delete(0,END)
#========================================================================================================================================      
def update():
#     #Database()
        if not tree.selection():
            mb.showerror('Error!', 'Please select an item from the database')
        else:

         connection = pymysql.connect(**db_config)
    #create Cursor
         conn = connection.cursor()   
         current_item = tree.focus()
         values = tree.item(current_item)
         selection = values["values"]
         tree.delete(current_item)
         conn.execute('DELETE FROM standardtable WHERE standardname=%s' % selection[0])
         connection.commit()
         display_records()
         add_record()
         display_records()
         reset_fields()
         messagebox.showinfo("Message","Updated Successfully")
def SearchRecord():
    #open databas
    
    connection = pymysql.connect(**db_config)
    #connector=pymysql.connect(**db_config)
    conn = connection.cursor()  
    print("hello")  
    #checking search text is empty or not
    if SEARCH.get() != "":
        #clearing current display data
        tree.delete(*tree.get_children())
        #select query with where clause
        conn.execute("select standardname,maxstudcount from standardtable where standardname like %s order by standardname ",("%{}%".format(SEARCH.get()),))
        #fetch all matching records
        fetch = conn.fetchall()
        #loop for displaying all records into GUI
        for data in fetch:
            tree.insert('', 'end', values=(data))
        conn.close()
        connection.close()


def update1():
    #connector=sqlite3.connect('standard.db')
    global standardname_strvar, maxstudcount_strvar 
    standardname=standardname_strvar.get()
    maxstudcount =   maxstudcount_strvar.get()
    connection = pymysql.connect(**db_config)  
    current_item = tree.focus()
    values = tree.item(current_item)
    selection = values["values"] 
  
    conn.execute('UPDATE   STANDARDTABLE SET  standardname=?,maxstudcount=? WHERE STANDARDID=? ',(standardname,maxstudcount, selection[0]))
    connection.commit()
    mb.showinfo("Message","Updated successfully")
    clear() 
    reset_fields()
        #refresh table data
    display_records()
#===============================================================================================================================================    
def SearchRecord1():
    #open database
    connector=sqlite3.connect('standard.db')
     
    #checking search text is empty or not
    if SEARCH.get() != "":
        #clearing current display data
        tree.delete(*tree.get_children())
        #select query with where clause
        #conn.execute("select * from subjecttable where subjectname like %s order by subjectid ",("%{}%".format(SEARCH.get()),))
        cursor=connector.execute("SELECT * FROM STANDARDTABLE WHERE standardname LIKE  order by standardid%s?",('%' + str(SEARCH.get()) + '%',))
               #fetch all matching records
        fetch = cursor.fetchall()
        #loop for displaying all records into GUI
        for data in fetch:
            tree.insert('', 'end', values=(data))
        cursor.close()
        reset_fields()
        connector.close()

def nextentry():
    maxstudcount.focus()
    




#==============================================================================================================================================
# Form design
   


#==============================================================================================================================
# Creating the background and foreground color variables1
lf_bg = 'DarkSeaGreen3' # bg color for the left_frame
cf_bg = 'DarkSeaGreen3' # bg color for the center_frame

# Creating the StringVar or IntVar variables
standardname_strvar = StringVar()
search = StringVar()
SEARCH=StringVar()
maxstudcount_strvar = StringVar()
# Placing the components in the main window
Label(main, text="STANDARD FORM", font=headlabelfont, bg='DarkSeaGreen3').pack(side=TOP, fill=X)
left_frame = Frame(main, bg=lf_bg)
left_frame.place(x=0, y=30, relheight=1, relwidth=0.2)
center_frame = Frame(main, bg=cf_bg)
center_frame.place(relx=0.2, y=30, relheight=1, relwidth=0.2)
right_frame = Frame(main, bg="DarkSeaGreen3")

right_frame.place(relx=0.4, y=30, relheight=0.9, relwidth=0.5)
#================================================================================================================================
# Placing components in the left frame
lbl_txtsearch = Label(center_frame, text="Enter name to Search", font=('verdana', 10),bg=lf_bg)
lbl_txtsearch.pack()
#==========================================================================================================================
    #creating search entry
search = Entry(center_frame, textvariable=SEARCH, font=('verdana', 10), width=12).place(x=100,y=20)
btn_search = Button(center_frame, text="Search", borderwidth=3,command=SearchRecord).place(x=120,y=60) 
btn_viewall=Button(center_frame, text='View All', borderwidth=3,font=('verdana', 10), command=display_records, width=10).place(x=100,y=100)
btn_update= Button(main,text="Update",command=update,width=8)
btn_update.place(x=390, y=185)

#================================================================================================================================

# Placing components in the left frame
Label(left_frame, text="Standard Name", font=labelfont, bg=lf_bg).place(relx=0.175, rely=0.05)
Label(left_frame, text="Max Student Count No.", font=labelfont, bg=lf_bg).place(relx=0.100, rely=0.18)

standardname = Entry(left_frame, width=19, textvariable=standardname_strvar, font=entryfont)
standardname.place(x=20, rely=0.1)
standardname.bind("<Return>",lambda event: nextentry())
maxstudcount = Entry(left_frame, width=19, textvariable=maxstudcount_strvar, font=entryfont)
maxstudcount.place(x=20, rely=0.23)
maxstudcount.bind("<Return>",lambda event: add_record())

Button(left_frame, text='Submit', font=labelfont,borderwidth=3, command=add_record, width=10).place(relx=0.1,rely=0.35)
Button(left_frame, text='View Record', font=labelfont,borderwidth=3,  command=view_record, width=10).place(relx=0.1, rely=0.45)
Button(left_frame, text='Clear Fields', font=labelfont, borderwidth=3, command=reset_fields, width=10).place(relx=0.1, rely=0.55)
Button(left_frame, text='Delete', font=labelfont,borderwidth=3,  command=remove_record, width=10).place(relx=0.1, rely=0.65)
Button(left_frame, text='Exit', font=labelfont,borderwidth=3,  command=main.destroy, width=10).place(relx=0.1, rely=0.75)
# #=====================================================================================================================================

# Placing components in the right frame
Label(right_frame,text='Standard Records',   font=headlabelfont, bg='DarkGreen', fg='LightCyan').pack(side=TOP, fill=X)
tree = ttk.Treeview(right_frame, height=100, selectmode=BROWSE,
                   columns=('StandardName', 'maxstudcount'))
X_scroller = Scrollbar(tree, orient=HORIZONTAL, command=tree.xview)
Y_scroller = Scrollbar(tree, orient=VERTICAL, command=tree.yview)
X_scroller.pack(side=BOTTOM, fill=X)
Y_scroller.pack(side=RIGHT, fill=Y)
tree.config(yscrollcommand=Y_scroller.set, xscrollcommand=X_scroller.set)
# tree.heading('Standard ID', text='ID', anchor=CENTER)
tree.heading('StandardName', text='standardname', anchor=CENTER)
tree.heading('maxstudcount', text='Maxstudcount', anchor=CENTER)
# tree.column('#0', width=0, stretch=NO)
#tree.column('#0', width=40, stretch=NO)
tree.column('#0', width=0, stretch=NO)
tree.column('#1', width=90, stretch=NO)
tree.place(y=30, relwidth=1, relheight=0.9, relx=0)
display_records()
#=========================================================================================================================================
# Finalizing the GUI window

main.update()
main.mainloop()
#=========================================================================================================================================

