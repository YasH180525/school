 #all check
#==========================================================================================================
from tkinter import *   #support the label and entry input
import tkinter.messagebox as mb
import tkinter.messagebox as mb   #support  the messagebox 
import tkinter.ttk as ttk   #support the treeview and ttk
import sqlite3  #support sqlite database
from tkinter import messagebox #support  the messagebox 
import tkinter.messagebox as tkMessageBox
import pymysql
#========================================================================================================
# Creating the universal font variables
headlabelfont = ("Noto Sans CJK TC", 15, 'bold')
labelfont = ('Helvetica', 14)
entryfont = ('Helvetica', 12)
#========================================================================================================
#connector=sqlite3.connect('subjectmaster.db')
db_config = {
    "host": "localhost",
    "user": "pc1",
    "password": "1234",
    "database": "subject",
}
connector = pymysql.connect(**db_config)
conn = connector.cursor()
conn.execute(
"CREATE TABLE IF NOT EXISTS SUBJECTTABLE (SUBJECTID INTEGER PRIMARY KEY  NOT NULL,SUBJECTNAME TEXT)"
)
print("hello")
# Creating the functions
prevent = False
#=============================================================================================================================================
def reset_fields():
   db_config = {
    "host": "localhost",
    "user": "pc1",
    "password": "1234",
    "database": "subject",
}
   #connector = pymysql.connect(**db_config)
   global subjectname_strvar,SEARCH
   for i in ['subjectname_strvar']:
       exec(f"{i}.set('')")
   SEARCH.set("")
#############################################################################################################################
   
def reset_form():
   global tree,SEARCH,subjectname
   tree.delete(*tree.get_children())
   reset_fields()
   #clear search text
   SEARCH.set("")
   subjectname.set("")
############################################################################################################################
def display_records():
   global prevent
   tree.delete(*tree.get_children())
   #connector = pymysql.connect(**db_config)
   connection = pymysql.connect(**db_config)
   conn=connection.cursor()
   conn.execute('SELECT subjectname FROM SUBJECTTABLE')
   data = conn.fetchall()
   for records in data:
       tree.insert('', END, values=records)
       tree.bind("<Double-1>",OnDoubleClick)
def OnDoubleClick(self):
     global prevent
#    getting focused item from treeview
     #set values in the fields
     current_item = tree.focus()
     values = tree.item(current_item)
     selection = values["values"]     
     subjectname_strvar.set(selection[1])
     prevent = True  
############################################################################################################################       
def view_record():
   global subjectname_strvar,tree
   global prevent
   connection = pymysql.connect(**db_config)
   if not tree.selection():
       mb.showerror('Error!', 'Please select a record to view')
   else:
        current_item = tree.focus()
        values = tree.item(current_item)
        selection = values["values"]
        subjectname_strvar.set(selection[0])         
       # prevent=True
##########################################################################################################################
def add_record():
   global subjectname_strvar
   global prevent
   subjectname = subjectname_strvar.get()        
   if not subjectname  :
       mb.showerror('Error!', "Please fill all the missing fields!!")
   else:
        #if prevent == False :   
         #  connector=sqlite3.connect('subjectmaster.db')             
           connection = pymysql.connect(**db_config)
           con=connection.cursor()
           sql='INSERT INTO SUBJECTTABLE (SUBJECTNAME) VALUES (%s)'
           val=( subjectname)
           con.execute(sql,val)
           
           connection.commit()
           display_records()
           connection.close()
#            main.config(cursor="wait")
#            main.update()
#  #       time.sleep(2)
#            main.config(cursor="")
                #file_1.write("Password: " +  self.root.ids.user_pass.text + "\n")
           reset_fields()
           messagebox.showinfo("Message","Saved Sucessfully")
    
#            mb.showinfo('Record added', f"Record of {subjectname} was successfully added")
#            display_records()
#            reset_fields()
#         else:
#            connector=sqlite3.connect('subjectmaster.db')
#            current_item = tree.focus()
#            values = tree.item(current_item)
#            selection = values["values"]
#         #update query
#            connector.execute('UPDATE SUBJECTTABLE SET SUBJECTNAME=? WHERE SUBJECTID = ?',(subjectname, selection[0]))
#            connector.commit()
#            mb.showinfo("Message","Updated successfully")         
#            display_records() 
#            reset_fields()
#            prevent = False
#     #refresh table data
#            connector.close()
# ##############################################################################################################
def update():
#     #Database()
        if not tree.selection():
            mb.showerror('Error!', 'Please select an item from the database')
        else:

         connection = pymysql.connect(**db_config)
    #create Cursor
         con = connection.cursor()   
         current_item = tree.focus()
         values = tree.item(current_item)
         selection = values["values"]
         tree.delete(current_item)
         con.execute('DELETE FROM subjecttable WHERE subjectid=%d' % selection[0])
        
         
        connection.commit()
        display_records()
        add_record()
        display_records()
        reset_fields()
        messagebox.showinfo("Message","Updated Successfully")


# def Update1():
#     global subjectname_strvar,tree
#     connector=sqlite3.connect('subjectmaster.db')
#     #applying empty validation
#     if not tree.selection():
#      mb.showerror('Error!', 'Please select an subject from the database')
          
#     #getting form data
#     subjectname=subjectname_strvar.get()
#     #getting selected data  
#     current_item = tree.focus()
#     values = tree.item(current_item)
#     selection = values["values"]
#         #update query
#     connector.execute('UPDATE SUBJECTTABLE SET SUBJECTNAME=? WHERE SUBJECTID = ?',(subjectname, selection[0]))
#     connector.commit()
#     mb.showinfo("Message","Updated successfully")
#     reset_fields()
#     display_records()   
#     #refresh table data
#     connector.close()
###########################################################################################################################
def clear():
        subjectname_strvar.delete(0,END)
###########################################################################################################################          
def remove_record():
   if not tree.selection():
       mb.showerror('Error!', 'Please select an item from the database')
   else:
        result = tkMessageBox.askquestion('Confirm', 'Are you sure you want to delete this record?',
                                          icon="warning")
        if result == 'yes':
            connection = pymysql.connect(**db_config)  
            conn = connection.cursor()
            current_item = tree.focus()
            values = tree.item(current_item)
            selection = values["values"]
            tree.delete(current_item)
            conn.execute('DELETE FROM SUBJECTTABLE WHERE SUBJECTID=%d' % selection[0])
            mb.showinfo('Done', 'The record you wanted deleted was successfully deleted.')
            connection.commit()
            display_records()     
#########################################################################################################################
def SearchRecord():
    #open database
    connection=pymysql.connect(**db_config)
    conn = connection.cursor()
    #checking search text is empty or not
    if SEARCH.get() != "":
        #clearing current display data
        tree.delete(*tree.get_children())
        #select query with where clause
#         mysql_conn.query_db(
#     "select * from table_one where col_name like %s order by id asc limit 5",
#      ("%{}%".format(param),))
        conn.execute("select * from subjecttable where subjectname like %s order by subjectid ",("%{}%".format(SEARCH.get()),))
        #conn.execute("select * from subjecttable where subjectname", ("%{}%".format(SEARCH.get()),))
#        conn.execute("SELECT * FROM subjecttable WHERE subjectname LIKE ?", ((SEARCH.get()),))
        #fetch all matching records
        fetch = conn.fetchall()
        #loop for displaying all records into GUI
        for data in fetch:
            tree.insert('', 'end', values=(data))
        conn.close()
        
        connection.close()


###########################################################################################################################

main = Tk()
main.title('Subject Management System')
main.geometry('1366x768')
main.config(bg="DarkSeaGreen3")
# Creating the background and foreground color variables1
lf_bg = 'DarkSeaGreen3' # bg color for the left_frame
cf_bg = 'DarkSeaGreen3' # bg color for the center_frame

# Creating the StringVar or IntVar variables
global SEARCH
search = StringVar()
subjectname=StringVar()
subjectname_strvar = StringVar()
#maxstudcount_strvar = StringVar()
SEARCH=StringVar()
# Placing the components in the main window
Label(main, text="SUBJECT FORM", font=headlabelfont, bg='DarkSeaGreen3').pack(side=TOP, fill=X)
#Left Frame
left_frame = Frame(main, bg=lf_bg)
left_frame.place(x=0, y=30, relheight=1, relwidth=0.2)
#Center Frame
center_frame = Frame(main, bg=cf_bg)
center_frame.place(relx=0.2, y=30, relheight=1, relwidth=0.2)
#Right Frame
right_frame = Frame(main, bg="DarkSeaGreen3")
right_frame.place(relx=0.4, y=30, relheight=0.9, relwidth=0.5)
Label(left_frame, text="Subject Name" , font=labelfont, bg=lf_bg).place(relx=0.175, rely=0.05)
subjectname = Entry(left_frame, width=19, textvariable=subjectname_strvar, font=entryfont)
subjectname.place(x=20, rely=0.1)
subjectname.bind("<Return>",lambda event: add_record())
######################################################################################################################
# Placing components in the left frame
lbl_txtsearch = Label(main, text="Enter name to Search", font=('verdana', 10),bg=lf_bg)
lbl_txtsearch.place(x=287,y=50)
#==========================================================================================================================
    #creating search entry
search = Entry(main, textvariable=SEARCH, font=labelfont,width=14 )
search.place(x=297,y=80)
btn_search = Button(main, text="Search", borderwidth=3,command=SearchRecord) 
btn_search.place(x=340,y=110)
btn_viewall=Button(main, text='View All', font=('verdana', 10),borderwidth=3, command=display_records, width=8).place(x=325,y=150)
# btn_update= Button(main,text="Update",command=update,width=8)
# btn_update.place(x=325,y=175)

###########################################################################################################################
    #creating search button
Button(left_frame, text='Submit', font=labelfont, command=add_record, borderwidth=3,width=10).place(relx=0.1,rely=0.25)
Button(left_frame, text='View Record', font=labelfont, command=view_record,borderwidth=3, width=10).place(relx=0.1, rely=0.35)
Button(left_frame, text='Clear Fields', font=labelfont, command=reset_fields,borderwidth=3, width=10).place(relx=0.1, rely=0.45)
Button(left_frame, text='Delete', font=labelfont, command=remove_record, borderwidth=3,width=10).place(relx=0.1, rely=0.55)
Button(left_frame, text='Exit', font=labelfont, command=main.destroy, borderwidth=3,width=10).place(relx=0.1, rely=0.65)
#Button(left_frame, text='Backup', font=labelfont, command=backup, borderwidth=3,width=10).place(relx=0.1, rely=0.75)
#######################################################################################################################
# Placing components in the right frame
Label(right_frame, text='Subject Records', font=headlabelfont, bg='DarkGreen', fg='LightCyan').pack(side=TOP, fill=X)
tree = ttk.Treeview(right_frame, height=100, selectmode="extended",
                   columns=('SubjectName'))
X_scroller = Scrollbar(tree, orient=HORIZONTAL, command=tree.xview)
Y_scroller = Scrollbar(tree, orient=VERTICAL, command=tree.yview)
X_scroller.pack(side=BOTTOM, fill=X)
Y_scroller.pack(side=RIGHT, fill=Y)
tree.config(yscrollcommand=Y_scroller.set, xscrollcommand=X_scroller.set)
#tree.heading('Subject ID', text='ID', anchor=CENTER)
tree.heading('SubjectName', text='Subjectname', anchor=CENTER)
#tree.column('#0', width=0, stretch=NO)
tree.column('#0', width=40, stretch=NO)
tree.place(y=30, relwidth=1, relheight=0.9, relx=0)
display_records()
# Finalizing the GUI window
main.update()
main.mainloop()


