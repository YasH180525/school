from tkinter import *   #support the label and entry input  pip install tkinter
import tkinter.messagebox as mb   #support  the messagebox 
from PIL import Image, ImageTk  # support image
import datetime #support date pip install datetime
from tkcalendar import DateEntry  # pip install tkcalendar
from tkinter import messagebox
import tkinter.ttk as ttk   #support the treeview and ttk
from tkinter.filedialog import askopenfiles
import sqlite3  #support sqlite database
import tkinter.messagebox as tkMessageBox
from tkcalendar import DateEntry  # pip install tkcalendar
import pymysql 
import  cv2 #support webcamera
import os #support provides the facility to establish the interaction between the user and the operating system. 
import speech_recognition as sr # voice recognition
import pyttsx3 #engine for voice recognition 3 install library
import pandas as pandas # convert excel file to pdf,html
import pandas as pd # object can invoke from pandas
import sqlite3
import babel
import tkinter as tk  # PEP8: `import *` is not preferred
from PIL import Image, ImageTk
import cv2

main = Tk()
main.title('TEACHER MASTER TABLE')
main.geometry('1366x768')
main.config(bg="DarkSeaGreen3")



teacherschoolid_strvar=StringVar()
teacherfullname_strvar=StringVar()
teacherBirthdate_strvar=StringVar()
teachercaste_strvar=StringVar()
teacherjod_strvar=StringVar()
teacherpfnumber_strvar=StringVar()
teacherretiredate_strvar=StringVar()
teacherusername_strvar=StringVar()
SEARCH=StringVar()
imageid=IntVar()
record_id = StringVar()
imagepath = StringVar()
imagename =  StringVar()
varun_label = StringVar()


db_config = {
    "host": "localhost",
    "user": "pc1",
    "password": "1234",
    "database": "teachermaster1",
}
r = sr.Recognizer()

# Creating the universal font variables

labelfont = ('Helvetica', 14)
headlabelfont = ("Times New Roman", 15, 'bold')
entryfont = ('Helvetica', 12)

hlb_btn_bg = 'Helvetica'

connector=pymysql.connect(**db_config)
cursor = connector.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS TEACHERTABLE2  (TEACHERID INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL ,TEACHERSCHOOLID VARCHAR(100)  ,TEACHERFULLNAME VARCHAR(100),TEACHERBIRTHDATE VARCHAR(100),TEACHERCASTE VARCHAR(100),TEACHERJOD VARCHAR(100),TEACHERPFNUMBER VARCHAR(100),TEACHERRETIREDATE VARCHAR(100),TEACHERUSERNAME VARCHAR(100))")
print("hello")
global prevent
prevent=False

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
    # print(voices[1].id)
engine.setProperty('voice', voices[0].id)
r = sr.Recognizer()

def listenteacher_name(*args):
        
     with sr.Microphone(device_index=1) as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=5)

     try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if teacherfullname.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                teacherfullname.insert(0,f"{query}\n")
            
            else:
                messagebox.showerror("Message","Say that again please!")
        

     except Exception as e:
        # print(e)    
        print("Say that again please...")  

def listenteacher_caste(*args):
        
    with sr.Microphone(device_index=1) as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=1,phrase_time_limit=5)
        print("Talk")
        #audio_text = r.listen(source,timeout=1,phrase_time_limit=3)
    print("Time over, thanks")
# recoginize_() method will throw a request error if the API is unreachable, hence using exception handling
    
    try:
        # using google speech recognition
        print("Text: "+r.recognize_google(audio))
    except:
         print("Sorry, I did not get that")
 
    try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if teachercaste.get() == '':
                #query1 = r.recognize_google(audio_text, language='en-in')
                teachercaste.insert(0,f"{query}\n")
            else:
                messagebox.showerror("Message","Say that again please!")
    except Exception as e:
        # print(e)    
        print("Say that again please...")  


def listenteacher_username(*args):
        
     with sr.Microphone(device_index=1) as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=3,phrase_time_limit=5)

     try:
            print("Recognizing...")    
            query = r.recognize_google(audio, language='mr')
            if teacherusername.get() == '':
                #query1 = r.recognize_google(audio, language='en-in')
                teacherusername.insert(0,f"{query}\n")
            
            else:
                messagebox.showerror("Message","Say that again please!")
        

     except Exception as e:
        # print(e)    
        print("Say that again please...")  

def next_entry_2(*args):
    if teacherschoolid_strvar.get() == "":
        teacherfullname.focus_set()
    elif teacherfullname.get() == "":
        teacherbirthdate.focus_set()

    else:
        print("Hii")
def reset_fields():
   global teacherschoolid_strvar,teacherfullname_strvar,teacherbirthdate,teachercaste_strvar,teacherjod,teacherpfnumber_strvar,teacherretiredate,teacherusername_strvar
   for i in ['teacherschoolid_strvar','teacherfullname_strvar','teachercaste_strvar','teacherpfnumber_strvar','teacherusername_strvar','teacher']:
       exec(f"{i}.set('')")
       teacherBirthdate_strvar.set('')
       teacherretiredate_strvar.set('')
       teacherjod_strvar.set('')
      
#    teacherbirthdate.set_date(datetime.datetime.now().date())
#    teacherjod.set_date(datetime.datetime.now().date())
#    teacherretiredate.set_date(datetime.datetime.now().date())
   SEARCH.set("")
   search.delete(0,END)
   varun_label.config(image = "")
   varun_label.image.blank()
   varun_label.image = None
   varun_label.pack_forget()
   teacherschoolid.focus()

def reset_form():
    global tree
    tree.delete(*tree.get_children())
    reset_fields()
    SEARCH.set("")




def display_records():
    tree.delete(*tree.get_children())
    connection = pymysql.connect(**db_config)
    conn = connection.cursor()
    conn.execute('SELECT * FROM TEACHERTABLE2')
    data = conn.fetchall()
    for records in data:
     tree.insert('', END,values=records)





def Insert():
        global Insert_id
        connection = sqlite3.connect('teachermaster1.db')
    #create Cursor
        con = connection.cursor()
        
        record_id = teacherschoolid.get()
        
    #query the database
        con.execute("SELECT * FROM teachertable2 WHERE teacherschoolid= " + record_id)
        
        records = con.fetchall()
        print(records)
        if records:
            messagebox.showwarning("Message","Record already exists")
            teacherschoolid.focus()
 
      
  
#===============================================================================================

def add_record():
   global teacherschoolid_strvar,teacherfullname_strvar,teacherbirthdate,teachercaste_strvar,teacherjod,teacherpfnumber,teacherpfnumber_strvar,teacherretiredate,teacherusername_strvar
   global prevent
   teacherschoolid=teacherschoolid_strvar.get()
   teacherfullname = teacherfullname_strvar.get()
   teacherBirthdate=teacherBirthdate_strvar.get()
   teachercaste=teachercaste_strvar.get()
   teacherJod=teacherjod_strvar.get()
   teacherpfnumber=teacherpfnumber_strvar.get()
   teacherRetiredate=teacherretiredate.get()
   #print(teacherretiredate)
   teacherusername =teacherusername_strvar.get()
#   listen()

   print(prevent)
   if teacherschoolid=="":
   # if not  teacherschoolid_strvar or not teacherfullname_strvar or not teacherBirthdate  or not teachercaste_strvar or not teacherJod or not teacherpfnumber_strvar or not teacherRetiredate or  not teacherusername_strvar:
      mb.showwarning('Message!', "Please fill Teacherschoolid the missing field!!")
      teacherschoolid.focus()
   else:
      connection = pymysql.connect(**db_config)
      conn = connection.cursor() 
      sql = "INSERT INTO teachertable2(TEACHERSCHOOLID,TEACHERFULLNAME,TEACHERBIRTHDATE,TEACHERCASTE,TEACHERJOD,TEACHERPFNUMBER,TEACHERRETIREDATE,TEACHERUSERNAME) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"
      val = (teacherschoolid,teacherfullname,teacherBirthdate,teachercaste,teacherJod,teacherpfnumber,teacherRetiredate,teacherusername)
      conn.execute(sql,val)
      connection.commit()
      mb.showinfo('Record added', f"Record of {teacherfullname} was successfully added") 
      connection.commit()
      display_records()
      conn.execute("select max(TEACHERID) from teachertable2")
      Imageid=conn.fetchone()
      print(Imageid)
      abc=str(Imageid)
      print(abc)
      connection.commit()
      print(Imageid) 
 #        abc='student'+(abc)
      print(abc)
      display_records()
      #         Source file path
      source = 'filename.jpg'
      print(source)
      #          destination file path
      dest = "teacher" + abc + ".jpg" #'GeekforGeeks/newfile.txt'
      print(dest)
            #    Now rename the source path
            #    to destination path
            #    using os.rename() method
      os.rename(source,dest)
      #shutil.move(source,dest)
      print("file renamed")
      

#===========================================================================================================
def view_record():
    global teacherid_intvar,teacherschoolid_strvar,teacherfullname_strvar,teacherbirthdate,teachercaste_strvar,teacherjod,teacherpfnumber_strvar,teacherretiredate,teacherusername_strvar,frame1
    global selection
    global prevent,filename
    #getting focused item from treeview
    curItem = tree.focus()
    contents = (tree.item(curItem))
    selection = contents['values']
    
    #set values in the fields
    
    teacherschoolid_strvar.set(selection[1]); teacherfullname_strvar.set(selection[2])
    # date = datetime.date(int(selection[3][:4]), int(selection[3][5:7]), int(selection[3][8:]))
    # teacherbirthdate.set_date(date);teachercaste_strvar.set(selection[4])
    teacherBirthdate_strvar.set(selection[3])
    teachercaste_strvar.set(selection[4])

    #date = datetime.date(int(selection[5][:4]), int(selection[5][5:7]), int(selection[5][8:]))
   
    teacherjod_strvar.set(selection[5])
    teacherpfnumber_strvar.set(selection[6]) 
    # date = datetime.date(int(selection[7][:4]), int(selection[7][5:7]), int(selection[7][8:]))
    teacherretiredate_strvar.set(selection[7])
    teacherusername_strvar.set(selection[8])

    prevent=True
    imageid=str(selection[0])
    #imageid="(" +str(selection[0]) + ",)"
    
    connector.commit()
    imagename='teacher('+imageid+ ',)' + ".jpg"
    #print(imagename)
    global image 
    image = Image.open(imagename)
    photo = ImageTk.PhotoImage(image)
    varun_label = Label(image=photo,height=150,width=150)
    #varun_label.place(x=260,y=160)
    varun_label.place(x=350,y=20)#place(x= 430,y=150)
     
    # Reading an image in default mode
    image = cv2.imread(imagepath)

    # Window name in which image is displayed
    window_name = 'image'     
    #window_name='C:\\Users\\kavit\\OneDrive\\Desktop\\aarya\\' + abc + '.jpg'

    if window_name:

    # Using cv2.imshow() method
    # Displaying the image
     # waits for user to press any key
    # (this is necessary to avoid Python kernel form crashing)
        cv2.waitKey(0)
    else:
        print("no image")

    # closing all open windows
    cv2.destroyAllWindows()
    prevent=False


def remove_record():
   if not tree.selection():
       mb.showerror('Error!', 'Please select an item from the database')
   else:
       result = tkMessageBox.askquestion('Confirm', 'Are you sure you want to delete this record?',
                                          icon="warning")
       if result == 'yes':
        connection = pymysql.connect(**db_config)
        conn = connection.cursor()
        current_item = tree.focus()
        values = tree.item(current_item)
        selection = values["values"]
        tree.delete(current_item)
        conn.execute('DELETE FROM TEACHERTABLE2 WHERE TEACHERID=%d' % selection[0])
       
        mb.showinfo('Done', 'The record you wanted deleted was successfully deleted.')
        connection.commit()
        display_records()




def Update():
    #Database()
    
   teacherschoolid=teacherschoolid_strvar.get()
   teacherfullname = teacherfullname_strvar.get()
   teacherBirthdate=teacherBirthdate_strvar.get()
   teachercaste=teachercaste_strvar.get()
   teacherJod=teacherjod_strvar.get()
   teacherpfnumber=teacherpfnumber_strvar.get()
   teacherRetiredate=teacherretiredate.get()
   #print(teacherretiredate)
   teacherusername =teacherusername_strvar.get()
#   listen()

   print(prevent)
   if teacherschoolid=="":
   # if not  teacherschoolid_strvar or not teacherfullname_strvar or not teacherBirthdate  or not teachercaste_strvar or not teacherJod or not teacherpfnumber_strvar or not teacherRetiredate or  not teacherusername_strvar:
      mb.showwarning('Message!', "Please fill Teacherschoolid the missing field!!")
      teacherschoolid.focus()
   else:
      connection = pymysql.connect(**db_config)
      conn = connection.cursor() 
      sql = "UPDATE teachertable2 SET TEACHERFULLNAME=%s,TEACHERBIRTHDATE=%s,TEACHERCASTE=%s,TEACHERJOD=%s,TEACHERPFNUMBER=%s,TEACHERRETIREDATE=%s,TEACHERUSERNAME=%s where TEACHERSCHOOLID=%s"
      val = (teacherfullname,teacherBirthdate,teachercaste,teacherJod,teacherpfnumber,teacherRetiredate,teacherusername,teacherschoolid)
      conn.execute(sql,val)
      connection.commit()
      mb.showinfo('Record Updated', f"Record of {teacherfullname} was successfully updated") 
      connection.commit()
      display_records()
      conn.execute("select max(TEACHERID) from teachertable2")
      Imageid=conn.fetchone()
      print(Imageid)
      abc=str(Imageid)
      print(abc)
      connection.commit()
      print(Imageid) 
 #        abc='student'+(abc)
      print(abc)
      display_records()
      #         Source file path
      source = 'filename.jpg'
      print(source)
      #          destination file path
      dest = "teacher" + abc + ".jpg" #'GeekforGeeks/newfile.txt'
      print(dest)
            #    Now rename the source path
            #    to destination path
            #    using os.rename() method
      os.rename(source,dest)
      #shutil.move(source,dest)
      print("file renamed")

###############################################################################################################################
        #function to search data
def SearchRecord():
    #open database
    connector=pymysql.connect()
    #checking search text is empty or not
    if SEARCH.get() != "":
        #clearing current display data
        tree.delete(*tree.get_children())
        #select query with where clause
        cursor=connector.execute("SELECT * FROM TEACHERTABLE2 WHERE TEACHERFULLNAME LIKE ?", ('%' + str(SEARCH.get()) + '%',))
        #fetch all matching records
        fetch = cursor.fetchall()
        #loop for displaying all records into GUI
        for data in fetch:
            tree.insert('', 'end', values=(data))
        cursor.close()
        connector.close()
 ############################################################################################################################

def clear():
        teacherschoolid_strvar.delete(0,END)
        teacherfullname_strvar.delete(0,END)
        teacherbirthdate.delete(0,END)
        teachercaste_strvar.delete(0,END)
        teacherjod.delete(0,END)
        teacherpfnumber_strvar.delete(0,END)
        teacherretiredate.delete(0,END)
        teacherusername_strvar.delete(0,END)
        search.delete(0,END)
        search.delete(0,END)
        SEARCH.set("")
        varun_label.delete(0,END)
        varun_label.set(" ")




# def print_file():
	


#     class MyFrame(wx.Frame):
#         def __init__(self, parent, title):
#             super(MyFrame, self).__init__(parent, title =title, size = (800,600))


#             self.panel = MyPanel(self)


# class MyPanel(wx.Panel):
#     def __init__(self, parent):
#         super(MyPanel, self).__init__(parent)


#         self.button = wx.Button(self, label = "Print Dialog", pos = (100,100))
#         self.Bind(wx.EVT_BUTTON, self.openDialog)



#     def openDialog(self, event):
#         data = wx.PrintDialogData()
#         data.EnableSelection(True)
#         data.EnablePrintToFile(True)
#         data.EnablePageNumbers(True)
#         data.SetMinPage(1)
#         data.SetMaxPage(10)


#         dialog = wx.PrintDialog(self, data)
#         #dialog.ShowModal()

#         if dialog.ShowModal() == wx.ID_OK:
#             data = dialog.GetPrintDialogData()
#             print('GetAllPages: %d\n' % data.GetAllPages())

#             dialog.Destroy()
# class MyFrame(wx.Frame):
#     def __init__(self, parent, title):
#         super(MyFrame, self).__init__(parent, title =title, size = (800,600))
 
 
#         self.panel = MyPanel(self)
 

# class MyApp(wx.App):
#     def OnInit(self):
#         self.frame = MyFrame(parent=None, title="Print Dialog")
#         self.frame.Show()
#         return True


# def printfiles():
#      app = MyApp()
#      app.MainLoop()
# 	# Ask for file (Which you want to print)
	# file_to_print = filedialog.askopenfilename(
	# initialdir="/", title="Select file",
	# filetypes=(("Text files", "*.txt"), ("all files", "*.*")))
	
	# if file_to_print:
		
	# 	# Print Hard Copy of File
	# 	win32api.ShellExecute(0, "print", file_to_print, None, ".", 0)

# --- functions ---  # PEP8: all functions after imports

# def show_frame():
#    # get frame
#    ret, frame = cap.read()
   
#    if ret:
#        # cv2 uses `BGR` but `GUI` needs `RGB`
#        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

#        # convert to PIL image
#        img = Image.fromarray(frame)

#        # convert to Tkinter image
#        photo = ImageTk.PhotoImage(image=img)
       
#        # solution for bug in `PhotoImage`
#        label.photo = photo
       
#        # replace image in label
#        label.configure(image=photo)  
   
#    # run again after 20ms (0.02s)
#    root.after(20, show_frame)

# # --- main ---

# cap = cv2.VideoCapture(0)

# root = tk.Tk()

# # create a Label to display frames
# label = tk.Label(root)
# label.pack(fill='both', expand=True)  # to resize label when resize window

# # start function which shows frame
# show_frame()

# root.mainloop()

# cap.release()
  
            
#########################################################################
# #
def photo_record():
        global photoid 
# 1.creating a video object
        
        video = cv2.VideoCapture(0) 
        #width,height = 100,100
        width ,height=0.6,1
        video.set(cv2.CAP_PROP_FRAME_WIDTH,width) 
        video.set(cv2.CAP_PROP_FRAME_HEIGHT,height)
        
# 2. Variable
        a = 0
# 3. While loop
        while True:
               a = a + 1
    # 4.Create a frame object

               check, frame1 = video.read()
               print(check) #prints true as long as the webcam is running
               print(frame1) #prints matrix values of each framecd 
               check, frame1 = video.read()
    # Converting to grayscale
              
            #   img_grayscale = cv2.imread('test.jpg',cv2.IMREAD_GRAYSCALE)
            #   img_unchanged = cv2.imread('test.jpg',cv2.IMREAD_UNCHANGED)

             #  gray = cv2.cvtColor(frame1,cv2.COLOR)
    # 5.show the frame!
              
               cv2.imshow("Capturing",frame1)
               #frame1.resize(150,150)
               frame1=varun_label
               
               cv2. width,height= 0.6,1
               # color 
               # = cv2.imread('filename.jpg',cv2.IMREAD_COLOR)
    # 6.for playing 

               key = cv2.waitKey(1)
               if key == ord('q') or key == ord('Q'):
                  connection=pymysql.connect(**db_config)
                  conn = connection.cursor()
                  conn.execute("select max(TEACHERID) from teachertable2")
                  Imageid= conn.fetchone()
                  print(Imageid)
                  abc=str(Imageid)
                  connection.commit()
                  print(Imageid) 
 #                    abc='student'+(abc)
                  print(abc)
                  display_records()
                  break
# 7. image saving
        retrun_value, image = video.read()
     
        cv2.imwrite("filename.jpg",image)
            
        #frame1=cv2.imshow("filename.jpg",frame1)
        
# 8. shutdown the camera
        video.release()
        cv2.destroyAllWindows 

def checkempty_teacherschoolid():
    if teacherschoolid_strvar.get() == '':
        messagebox.showerror("Message","Please fill the teacherschoolid!")



def voice_function():
    teacherfullname.bind('<FocusIn>',lambda event:listenteacher_name())
    teachercaste.bind('<FocusIn>',lambda event: listenteacher_caste())
    #teacherusername.bind('<FocusIn>',lambda event: listenteacher_username())
#=================================================================================================
def ExporttoExcel():
    import pandas as sql

   #  import excelregister
     # import the modules

# connect the mysql with the python
    con=pymysql.connect(**db_config)

# read the data
    df=sql.read_sql('select * from teachertable2',con)

# print the data
    #print(df)

# export the data into the excel sheet
    df.to_excel('D:\\reports\\teacher.xlsx')
    # excelregister
    messagebox.showinfo("Message","Excel File Created")



def go_to_next_entry(event, entry_list, this_index):
    next_index = (this_index + 1) % len(entry_list)
    entry_list[next_index].focus_set()

# Creating the background and foreground color variables1
lf_bg = 'DarkSeaGreen3' # bg color for the left_frame
cf_bg = 'darkSeaGreen3' # bg color for the center_frame

# Creating the StringVar or IntVar variables
global teacherschoolid

# Placing the components in the main window
Label(main, text="TEACHER FORM", font=headlabelfont, bg='DarkSeaGreen3').pack(side=TOP, fill=X)

middle_frame=Frame(main,bg="DarkSEaGreen3")
middle_frame.place(relx=0.1, y=0, relheight=0.1, relwidth=0.1)
right_frame = Frame(main, bg="DarkSeaGreen3")
right_frame.place(relx=0.4, y=25, relheight=0.9, relwidth=0.59)
lbl_txtsearch = Label(main, text="Enter name to Search", font=('verdana', 10),bg=lf_bg).place(x=390,y=230)
    #creating search entry
search = Entry(main, textvariable=SEARCH, font=('verdana', 15), width=10)
search.place(x=410,y=260)
btn_search = Button(main, text="Search", command=SearchRecord).place(x=420,y=300)
btn_viewall=Button(main, text='View All', command=display_records,width=8).place(x=470, y=300)
btn_update = Button(main,text="Update",command=Update,width=8).place(x=430, y=330)
lbl_teacherschoolid=Label(main, text="Teacher Schoolid",font=labelfont, bg=lf_bg).place(x=27, y=20)
teacherschoolid=Entry(main,width=15,textvariable=teacherschoolid_strvar,font=entryfont)
teacherschoolid.place(x=180,y=20)
teacherschoolid.bind('<FocusOut>',lambda event: checkempty_teacherschoolid())

lbl_teacherfullname=Label(main, text="TeacherfullName", font=labelfont, bg=lf_bg).place(x=27,y=80)
teacherfullname=Entry(main, width=15, textvariable=teacherfullname_strvar,font = entryfont)
teacherfullname.place(x=180,y=80)
   
lbl_teacherbirthdate=Label(main, text="Teacher Birthdate", font=labelfont, bg=lf_bg).place(x=27,y=140)
teacherbirthdate = Entry(main,textvariable=teacherBirthdate_strvar,font=entryfont)
teacherbirthdate.place(x=180, y=140)
lbl_teachercaste=Label(main, text="Teacher Caste", font=labelfont, bg=lf_bg).place(x=27, y=200)
teachercaste=Entry(main, width=15, textvariable=teachercaste_strvar,font = entryfont)
teachercaste.place(x=180, y=200)

lbl_teacherjod=Label(main, text="Teacher jod", font=labelfont, bg=lf_bg).place(x=27, y=270)
teacherjod = Entry(main,textvariable=teacherjod_strvar,font=entryfont)
teacherjod.place(x=180, y=270)
lbl_teacherpfnumber=Label(main,text="Teacher PFNumber",font=labelfont,bg=lf_bg).place(x=27, y=330)
teacherpfnumber=Entry(main, width=12, textvariable=teacherpfnumber_strvar,font = entryfont).place(x=210, y=335)
lbl_teacherretiredate=Label(main, text="Teacher Retire Date", font=labelfont, bg=lf_bg).place(x=27, y=400)
teacherretiredate = Entry(main,textvariable=teacherretiredate_strvar,font=entryfont)
teacherretiredate.place(x=220, y=400)
lbl_teacherusername=Label(main,text="Teacher username",font=labelfont,bg=lf_bg).place(x=27, y=460)
teacherusername=Entry(main, width=12, textvariable=teacherusername_strvar,font = entryfont)
teacherusername.place(x=210, y=465)
btn_upload=Button(main,text="Take photo",command=photo_record,width=15).place(x= 430,y=200)
#============================================================================================================
btn_submit=Button(main, text='Submit ',borderwidth=3,font=('verdana', 10),command=add_record).place(x=27, y=520)
btn_view=Button(main, text='View Record', borderwidth=3,font=('verdana', 10),command=view_record).place(x=100, y=520)
#btn_update=Button(main, text="Update",borderwidth=3,font=labelfont, command=Update,width=15).place( relx=0.1, rely=0.55)
btn_clear=Button(main, text='Clear Fields', borderwidth=3,font=('verdana', 10),command=reset_fields).place(x=200 ,y=520)
btn_del=Button(main, text='Delete Record',borderwidth=3,font=('verdana', 10),  command=remove_record).place(x=400, y=520)

btn_report=Button(main, text='Excel', borderwidth=3,font=('verdana', 10), command=ExporttoExcel).place(x=87, y=620)
btn_voice =Button(main, text='Voice Form', borderwidth=3,font=('verdana', 10),command=voice_function).place(x=300, y=520)

btn_exit=Button(main, text='Exit', borderwidth=3, font=('verdana', 10), command=main.destroy).place(x=157, y=620)
#webcamera_button=Button(main,text='take photo',font=labelfont,command=photo_record, width=10).place(relx=0.025,rely=0.85)
# Placing components in the right frame
Label(right_frame, text='TEACHERS Records', font=headlabelfont, bg='DarkGreen', fg='LightCyan').pack(side=TOP, fill=X)
tree = ttk.Treeview(right_frame, height=100, selectmode=BROWSE,
                   columns=('teacherid','teacherschoolid','teacherfullName', "teacherBirthdate","teacherCaste", "teacherJOD","teacherPFNumber","teacherretiredate","teacherusername"))
X_scroller = Scrollbar(tree, orient=HORIZONTAL, command=tree.xview)
Y_scroller = Scrollbar(tree, orient=VERTICAL, command=tree.yview)
X_scroller.pack(side=BOTTOM, fill=X)
Y_scroller.pack(side=RIGHT, fill=Y)
tree.config(yscrollcommand=Y_scroller.set, xscrollcommand=X_scroller.set)
tree.heading('teacherid',text='Id',anchor=CENTER)
tree.heading('teacherschoolid', text='SchoolId', anchor=CENTER)
tree.heading('teacherfullName', text='Fullname', anchor=CENTER)
tree.heading('teacherBirthdate', text='Birthdate', anchor=CENTER)
tree.heading('teacherCaste',text='Caste',anchor=CENTER)
tree.heading('teacherJOD', text='Jod', anchor=CENTER)
tree.heading('teacherretiredate', text='RetiredDate', anchor=CENTER)
tree.heading('teacherPFNumber', text='PFNumber', anchor=CENTER)
#tre1e.heading('teacherjod', text='jod', anchor=CENTER)
tree.heading('teacherusername', text='Username', anchor=CENTER)
tree.column('#0', width=0, stretch=NO)
tree.column('#1', width=30, stretch=NO)
tree.column('#2', width=70, stretch=NO)
tree.column('#3', width=80, stretch=NO)
tree.column('#4', width=90, stretch=NO)
tree.column('#5', width=100, stretch=NO)
tree.column('#6', width=110, stretch=NO)
tree.column('#7', width=120, stretch=NO)
tree.column('#8', width=130, stretch=NO)
tree.place(y=30, relwidth=1, relheight=0.9, relx=0)
#tree.place(y=30, relwidth=1, relheight=0.9, relx=0)
display_records()
# Finalizing the GUI window

entries = [child for child in main.winfo_children() if isinstance(child, Entry)]
for idx, entry in enumerate(entries):
    entry.bind('<Return>', lambda e, idx=idx: go_to_next_entry(e, entries, idx))
main.update()
main.mainloop()



