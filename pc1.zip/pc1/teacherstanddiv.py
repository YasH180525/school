from cgitb import text
import tkinter as tk
from tkinter import Button, StringVar, ttk
import pymysql
from tkinter import *   #support the label and entry input
import tkinter.messagebox as mb
import tkinter.messagebox as mb   #support  the messagebox 
import tkinter.ttk as ttk   #support the treeview and ttk
from tkinter import messagebox #support  the messagebox 
import tkinter.messagebox as tkMessageBox
headlabelfont = ("Times New Roman", 15, 'bold')
labelfont = ('Helvetica', 14)
entryfont = ('Helvetica', 12)


db_config={
    "user":"kavita",
    "host":"localhost",
    "password":"1981",
    "database":"teacherstanddiv"
}
def reset_fields():
   # global studstanddivid,registerid,standardid,divisionid,standardname,fullname,divisionname
   
   # for i in ['studstanddivid','registerid','standardid','divisionid','standardname','fullname','divisionname']:
   #    exec(f"{i}.set('')")
   pass
def reset_form():
   global tree
   #tree.delete(*tree.get_children())
   reset_fields()
   #SEARCH.set(" ")

def display_records():
    tree.delete(*tree.get_children())
    connection = pymysql.connect(**db_config)
    cursor = connection.cursor()
    curr=cursor.execute("select teacherfullname,standardname,divisionname from teacherstanddivtable")
    #cursor=conn.execute("select fullname,standardname,divisionname from newregister3,standardtable,divisiontable where studstanddivtable.registerid=newregister3.registerid and studstanddiv.standardid=dtandardtable.standardid and studstanddiv.divisionid=divisionid.divisiontable")
    #cursor=conn.execute("select fullname,standardname,divisionname from studstanddivtable where registerid=%s and standardid=%s and divisionid=%s",(studentfullname.get(),standardname.get(),divisionname.get()))
    data = cursor.fetchall()
    for records in data:
            tree.insert('',END, values="\t"+records[0]+ records[1]+"\t"+records[2]+"\t"+records[1])
         #   tree.insert('',END, values=records[5])
       
         #  for records1 in data1:
         #    tree.insert('',END, values=records1[1])
         #  for records2 in data2:
         #     tree.insert('',END, values=records2)

# def display_records():
#    global tree
#    # name_search = registerid.get()
#    tree.delete(*tree.get_children())
#    connection = pymysql.connect(**db_config)
#    cursor = connection.cursor()
#    #curr = cursor.execute('SELECT registernum, studentid,studentname,adharnumber,fathersname,surname,mothersname,mobileno,address,nationality,mothertongue,dharma,jat,potjat,Birthdate,birthplace,oldschool,Admidate,admistd,studyprogress,behaviour,Schoolleftdate,schoolleftreason,remark,Bankaccountno,Bankname,Bankbranch,Bankifsc,pustaknumber,lcyn,Leavingcertificateissuedate, taluka, jhila,rajya FROM newregister3')
#    cursor.execute('SELECT * FROM newregister3 where registerid =%s',(studname))
#    data = cursor.fetchall()
#    #print(data) 
#    for records in data:
#        tree.insert('', END, values=records[5])
# def view_record():
#    global studstanddivid,registerid,standardid,divisionid
#    if not tree.selection():
#        mb.showerror('Error!', 'Please select a record to view')
#    else:
#         current_item = tree.focus()
#         values = tree.item(current_item)
#         selection = values["values"]
#         studstanddivid.set(selection[0]),st
# def search_registerid():
   
   
def update():
   
   connection_divisionid = pymysql.connect(**db_config)
   cursor_divsionid = connection_divisionid.cursor()
   
   # cursor_divisionid = connection_registerid.cursor()
   
   
   cursor_divsionid.execute("SELECT divisionid from divisiontable where divisionname=%s",(divisionname.get()))
   # cursor_divisionid.execute("SELECT divisionid from divisiontable where divisionid=%s",(divisionname.get()))

   
   records_divsionid = cursor_divsionid.fetchall()
   # records_divisionid = cursor_registerid.fetchall()

   
   # for record_divisionid in records_divsionid:   
   #    pass
   # divisionid = record_divisionid[0]

   connection_standardid = pymysql.connect(**db_config)
   cursor_standardid = connection_standardid.cursor()
   # cursor_divisionid = connection_registerid.cursor()

   cursor_standardid.execute("SELECT standardid from standardtable where standardname=%s",(standardname.get()))
   # cursor_divisionid.execute("SELECT divisionid from divisiontable where divisionid=%s",(divisionname.get()))

   records_standardid = cursor_standardid.fetchall()
   # records_divisionid = cursor_registerid.fetchall()
   
   # for record_standardid in records_standardid:   
   #    pass
   # standardid = record_standardid[0]

   connection_teacherid = pymysql.connect(**db_config)
   cursor_teacherid = connection_teacherid.cursor()
   cursor_teacherid.execute("SELECT teacherid from teachertable2 where teacherfullname=%s",(teacherfullname.get()))
   records_teacherid = cursor_teacherid.fetchall()
   
  
    # "UPDATE table SET telefonnummer = ? WHERE telefonnummer = ?"
   sql = 'UPDATE teacherstanddivtable SET standardname=%s,divisionname=%s,registerid=%s,standardid=%s,divisionid=%s where fullname=%s' #36  
   val = (standardname.get(),divisionname.get(),records_teacherid,records_standardid,records_divsionid,teacherfullname.get())
   conn.execute(sql,val)    
   connection.commit()
   mb.showinfo('Record Updated', f"Record of {teacherfullname.get()} was successfully updated")
   
   
      #  global standard
       
      #  standard = record_standardid[0]

# def search_divisionid():
   
   
      #  global division
      #  division = record_divisionid[0]

def add_record():
   connection_divisionid = pymysql.connect(**db_config)
   cursor_divsionid = connection_divisionid.cursor()
   # cursor_divisionid = connection_registerid.cursor()
   
   
   cursor_divsionid.execute("SELECT divisionid from divisiontable where divisionname=%s",(divisionname.get()))
   # cursor_divisionid.execute("SELECT divisionid from divisiontable where divisionid=%s",(divisionname.get()))

   
   records_divsionid = cursor_divsionid.fetchall()
   # records_divisionid = cursor_registerid.fetchall()

   
   # for record_divisionid in records_divsionid:   
   #    pass
   # divisionid = record_divisionid[0]

   connection_standardid = pymysql.connect(**db_config)
   cursor_standardid = connection_standardid.cursor()
   # cursor_divisionid = connection_registerid.cursor()

   cursor_standardid.execute("SELECT standardid from standardtable where standardname=%s",(standardname.get()))
   # cursor_divisionid.execute("SELECT divisionid from divisiontable where divisionid=%s",(divisionname.get()))

   records_standardid = cursor_standardid.fetchall()
   # records_divisionid = cursor_registerid.fetchall()
   
   # for record_standardid in records_standardid:   
   #    pass
   # standardid = record_standardid[0]

   connection_teacherid = pymysql.connect(**db_config)
   cursor_teacherid = connection_teacherid.cursor()
   cursor_teacherid.execute("SELECT teacherid from teachertable2 where teacherfullname=%s",(teacherfullname.get()))
   records_teacherid = cursor_teacherid.fetchall()
   
   teacherfullname=teacherfullname.get() 
   #add connection
   connection = pymysql.connect(**db_config)
   conn = connection.cursor()

   sql = "INSERT INTO teacherstanddivtable(teacherfullname,divisionname,standardname,registerid,standardid,divisionid) VALUES(fullname=%s,divisionname=%s,standardname=%s,registerid=%s,standardid=%s,divisionid=%s)"
   val = (teacherfullname.get(),divisionname.get(),standardname.get(),records_teacherid,records_standardid,records_divsionid)
   conn.execute(sql,val)
   connection.commit()
   mb.showinfo('Record Added', f"Record of {teacherfullname.get()} was successfully added")


def remove_record():
   if not tree.selection():
       mb.showerror('Error!', 'Please select an item from the database')
   else:
        result = tkMessageBox.askquestion('Confirm', 'Are you sure you want to delete this record?',
                                          icon="warning")
        if result == 'yes':
         connection = pymysql.connect(**db_config)
         con = connection.cursor()   
         current_item = tree.focus()
         values = tree.item(current_item)
         selection = values["values"]
         tree.delete(current_item)
         con.execute('DELETE FROM teacherstanddivtable WHERE teacherid=%s,standardid=%s,divisionid=%s' % selection[0])
        
         mb.showinfo('Done', 'The record you wanted deleted was successfully deleted.')
         connection.commit()
         display_records()
         reset_fields()

 
# def searchrecord():
#   global studname
#   name = StringVar()
#   studname = registerid.get()
#   connection_Search = pymysql.connect(**db_config)
#   conn_search = connection_Search.cursor()
#   conn_search.execute("SELECT * FROM newregister3 where registerid=%s",((fullname))) 
#   record_search = conn_search.fetchall()
#   global record

#   for record in record_search:  
#      pass
      
      #   print("hello")
        # 
connection = pymysql.connect(**db_config)
conn = connection.cursor()
conn.execute("select teacherfullname from teachertable2")
records= conn.fetchall()
connection1 = pymysql.connect(**db_config)
conn1 = connection1.cursor()
conn1.execute("select standardname from standardtable")
records1= conn1.fetchall()
connection2 = pymysql.connect(**db_config)
conn2 = connection2.cursor()
conn2.execute("select divisionname from divisiontable")
records2= conn2.fetchall()


# Creating tkinter window
main = tk.Tk()
main.title('Teacher Standard Division Management System')
main.geometry('1366x768')
main.config(bg="DarkSeaGreen3")

#display_records()
lf_bg = "DarkSeaGreen3" # bg color for the main
cf_bg = 'PaleGreen' # bg color for the main
studstanddivid=StringVar()
right_frame = Frame(main, bg="Gray35")
right_frame.place(relx=0.69, y=14, relheight=1, relwidth=0.3)
global tree
teacherstanddivid=StringVar()
teacherfullname=StringVar()
standardname=StringVar()
divisionname=StringVar()
studname=StringVar()
name = StringVar()
# ttk.Label=Label(main, text="studstanddivid",font=labelfont, bg=lf_bg).place(x=27, y=20)
# studstanddivid=Entry(main,width=15,textvariable=studstanddivid,font=entryfont)
# studstanddivid.place(x=180,y=20)
ttk.Label=Label(main, text="Teacher\n  fullname",font=labelfont, bg=lf_bg).place(x=8, y=50)
teacherfullname= ttk.Combobox(main, width=20, textvariable=teacherfullname,font=entryfont)
teacherfullname.place(x=100,y=60)
teacherfullname['values'] = (records)
#studentname.bind('<Return>',lambda event: display_records())
ttk.Label=Label(main, text="Standard \n name",font=labelfont, bg=lf_bg).place(x=350, y=60)
standardname = ttk.Combobox(main, width=10, textvariable=standardname,font=entryfont)
standardname.place(x=450,y=60)
standardname['values'] = (records1)
ttk.Label=Label(main, text="Division\n name",font=labelfont, bg=lf_bg).place(x=590, y=60)
divisionname = ttk.Combobox(main, width=6, textvariable=divisionname,font=entryfont)
divisionname.place(x=670,y=60)
divisionname['values'] = (records2)
# divisionname.bind("<Return>",lambda event: update())


submit_button=Button(main, text='Submit', font=labelfont,command=add_record, width=10).place(x=15,y=500) 
Update_button = Button(main,text='Update',font=labelfont,command=update, width=10).place(x=15,y=650) 

view_button=Button(main, text='View Record', font=labelfont, command=exit ,width=10).place(x=150,y=650)

clear_button=Button(main, text='Clear', font=labelfont, command=reset_fields, width=10).place(x=285,y=650)
search_button=Button(main, text='Search', font=labelfont,command=display_records, width=10).place(x=435,y=650) 

delete_button=Button(main, text='Delete', font=labelfont, command=remove_record, width=10).place(x=555,y=650)


exit_button=Button(main, text='Exit', font=labelfont, command=main.destroy, width=10).place(x=815,y=650)
# Placing components in the right frame

Label(right_frame, text='Register Records', font=headlabelfont, bg='DarkGreen', fg='LightCyan').pack(side=TOP, fill=X)
tree = ttk.Treeview(right_frame, height=100, selectmode=BROWSE,
                   columns=('teacherfullname', 'standardname','divisionname'))
X_scroller = Scrollbar(tree, orient=HORIZONTAL, command=tree.xview)
Y_scroller = Scrollbar(tree, orient=VERTICAL, command=tree.yview)
X_scroller.pack(side=BOTTOM, fill=X)
Y_scroller.pack(side=RIGHT, fill=Y)
tree.config(yscrollcommand=Y_scroller.set, xscrollcommand=X_scroller.set)
#tree.heading('studstanddivid', text='studstanddivid', anchor=CENTER)
tree.heading('teacherfullname', text='Teacherfullname', anchor=CENTER)
tree.heading('standardname', text='Standardname', anchor=CENTER)
tree.heading('divisionname', text='division name', anchor=CENTER)
#tree.heading('aadharnumber', text='Aadharnumber', anchor=CENTER)
tree.column('#0', width=0, stretch=NO, minwidth=0)
tree.column('#1', width=40, stretch=NO,minwidth=0)
tree.column('#2', width=80, stretch=NO,minwidth=0)
#tree.column('#3', width=120, stretch=NO,minwidth=0)
#tree.column('#4', width=120, stretch=NO,minwidth=0)
tree.place(y=30, relwidth=1, relheight=0.9, relx=0)
display_records()



main.mainloop()
